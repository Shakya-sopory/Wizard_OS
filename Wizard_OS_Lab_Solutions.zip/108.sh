#!/bin/bash
# usage: ./108.sh [config.ini]
f=${1:-config.ini}
[ -f "$f" ] || { echo "File not found: $f" >&2; exit 1; }
sed -i.bak 's/DEBUG=false/DEBUG=true/g' "$f"          # -i edits in place, .bak keeps a backup copy
grep -n "DEBUG" "$f"
