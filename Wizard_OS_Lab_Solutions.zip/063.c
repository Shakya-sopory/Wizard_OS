#include <stdio.h>
#include <stdatomic.h>
#include <pthread.h>
#define N 1000000
long counter = 0;
atomic_flag lock = ATOMIC_FLAG_INIT;
static void spin_lock(void)   { while (atomic_flag_test_and_set_explicit(&lock, memory_order_acquire)) ; }   /* busy wait */
static void spin_unlock(void) { atomic_flag_clear_explicit(&lock, memory_order_release); }
void *inc(void *a) {
    for (int i = 0; i < N; i++) { spin_lock(); counter++; spin_unlock(); }
    return NULL;
}
int main(void) {
    pthread_t a, b;
    pthread_create(&a, NULL, inc, NULL); pthread_create(&b, NULL, inc, NULL);
    pthread_join(a, NULL); pthread_join(b, NULL);
    printf("Expected %d, got %ld %s\n", 2 * N, counter, counter == 2L * N ? "(correct)" : "(WRONG)");
    return 0;
}
