/* Prints ALL safe sequences using backtracking */
#include <stdio.h>
#define MAXP 10
#define MAXR 10
int n, m, alloc[MAXP][MAXR], need[MAXP][MAXR], used[MAXP], seq[MAXP], total = 0;
void solve(int depth, int *work) {
    if (depth == n) {
        total++; printf("%3d: ", total);
        for (int i = 0; i < n; i++) printf("P%d%s", seq[i], i < n - 1 ? " " : "\n");
        return;
    }
    for (int i = 0; i < n; i++) {
        if (used[i]) continue;
        int ok = 1;
        for (int j = 0; j < m; j++) if (need[i][j] > work[j]) { ok = 0; break; }
        if (!ok) continue;
        int nw[MAXR];
        for (int j = 0; j < m; j++) nw[j] = work[j] + alloc[i][j];
        used[i] = 1; seq[depth] = i;
        solve(depth + 1, nw);
        used[i] = 0;                                              /* backtrack */
    }
}
int main(void) {
    int max[MAXP][MAXR], avail[MAXR];
    printf("Processes and resource types: ");
    if (scanf("%d %d", &n, &m) != 2 || n <= 0 || m <= 0 || n > MAXP || m > MAXR) return 1;
    printf("Allocation:\n"); for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) scanf("%d", &alloc[i][j]);
    printf("Max:\n");        for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) scanf("%d", &max[i][j]);
    printf("Available: ");   for (int j = 0; j < m; j++) scanf("%d", &avail[j]);
    for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) need[i][j] = max[i][j] - alloc[i][j];
    solve(0, avail);
    if (total == 0) printf("No safe sequence exists: the state is unsafe.\n"); else printf("Total safe sequences: %d\n", total);
    return 0;
}
