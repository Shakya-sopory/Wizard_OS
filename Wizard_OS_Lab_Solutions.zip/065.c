#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#define SIZE 5
#define P 3
#define C 3
#define PER 6                       /* items per producer; consumers share P*PER items */
int buffer[SIZE], in = 0, out = 0, produced_total = 0;
sem_t empty, full, mutex;
void *producer(void *arg) {
    int id = (int)(long)arg;
    for (int i = 0; i < PER; i++) {
        int item = id * 100 + i;
        sem_wait(&empty); sem_wait(&mutex);
        buffer[in] = item; in = (in + 1) % SIZE;
        printf("Producer %d produced %d\n", id, item);
        sem_post(&mutex); sem_post(&full);
        usleep(1000);
    }
    return NULL;
}
void *consumer(void *arg) {
    int id = (int)(long)arg;
    for (int i = 0; i < PER; i++) {               /* each consumer takes exactly PER items, so all threads terminate */
        sem_wait(&full); sem_wait(&mutex);
        int item = buffer[out]; out = (out + 1) % SIZE;
        printf("          Consumer %d consumed %d\n", id, item);
        sem_post(&mutex); sem_post(&empty);
        usleep(2000);
    }
    return NULL;
}
int main(void) {
    sem_init(&empty, 0, SIZE); sem_init(&full, 0, 0); sem_init(&mutex, 0, 1);
    pthread_t p[P], c[C];
    for (long i = 0; i < P; i++) pthread_create(&p[i], NULL, producer, (void *)(i + 1));
    for (long i = 0; i < C; i++) pthread_create(&c[i], NULL, consumer, (void *)(i + 1));
    for (int i = 0; i < P; i++) pthread_join(p[i], NULL);
    for (int i = 0; i < C; i++) pthread_join(c[i], NULL);
    printf("All %d items produced and consumed.\n", P * PER);
    return 0;
}
