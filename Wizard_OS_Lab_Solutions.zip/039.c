#include <stdio.h>
#include <stddef.h>
#include <stdint.h>
#define POOL_SIZE (1024 * 1024)
static unsigned char pool[POOL_SIZE] __attribute__((aligned(16)));
typedef struct Chunk { size_t size; int free; struct Chunk *next; } Chunk;     /* header of every chunk */
static Chunk *head = NULL;
static void init(void) { head = (Chunk *)pool; head->size = POOL_SIZE - sizeof(Chunk); head->free = 1; head->next = NULL; }
void *my_malloc(size_t n) {
    if (!head) init();
    n = (n + 15) & ~(size_t)15;                                   /* 16-byte alignment */
    for (Chunk *c = head; c; c = c->next) {
        if (c->free && c->size >= n) {                           /* first fit */
            if (c->size >= n + sizeof(Chunk) + 16) {             /* split the chunk */
                Chunk *r = (Chunk *)((unsigned char *)(c + 1) + n);
                r->size = c->size - n - sizeof(Chunk); r->free = 1; r->next = c->next;
                c->size = n; c->next = r;
            }
            c->free = 0;
            return (void *)(c + 1);
        }
    }
    return NULL;                                                  /* out of memory */
}
void my_free(void *ptr) {
    if (!ptr) return;
    Chunk *c = (Chunk *)ptr - 1;
    c->free = 1;
    for (Chunk *x = head; x; x = x->next)                         /* coalesce adjacent free chunks */
        while (x->free && x->next && x->next->free) { x->size += sizeof(Chunk) + x->next->size; x->next = x->next->next; }
}
static void dump(const char *t) {
    printf("%s:", t);
    for (Chunk *c = head; c; c = c->next) printf(" [%s %zu]", c->free ? "free" : "used", c->size);
    printf("\n");
}
int main(void) {
    void *a = my_malloc(100), *b = my_malloc(200), *c = my_malloc(300);
    dump("after 3 allocs");
    my_free(b); dump("after free(b)");
    my_free(a); dump("after free(a) (coalesced)");
    void *d = my_malloc(250); (void)d; (void)c;
    dump("after alloc 250");
    return 0;
}
