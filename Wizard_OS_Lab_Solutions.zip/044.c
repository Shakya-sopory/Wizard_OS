/* May hang on purpose: a circular wait. Stop with Ctrl-C. Compile: gcc 044.c -o dead -pthread */
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
pthread_mutex_t lock1 = PTHREAD_MUTEX_INITIALIZER, lock2 = PTHREAD_MUTEX_INITIALIZER;
void *t1(void *a) {
    pthread_mutex_lock(&lock1); printf("T1 holds lock1\n");
    sleep(1);                                       /* give T2 time to take lock2 */
    printf("T1 waiting for lock2...\n");
    pthread_mutex_lock(&lock2);
    printf("T1 got both\n");
    pthread_mutex_unlock(&lock2); pthread_mutex_unlock(&lock1);
    return NULL;
}
void *t2(void *a) {
    pthread_mutex_lock(&lock2); printf("T2 holds lock2\n");
    sleep(1);
    printf("T2 waiting for lock1...\n");
    pthread_mutex_lock(&lock1);
    printf("T2 got both\n");
    pthread_mutex_unlock(&lock1); pthread_mutex_unlock(&lock2);
    return NULL;
}
int main(void) {
    pthread_t a, b;
    pthread_create(&a, NULL, t1, NULL); pthread_create(&b, NULL, t2, NULL);
    pthread_join(a, NULL); pthread_join(b, NULL);       /* never returns: deadlock */
    return 0;
}
