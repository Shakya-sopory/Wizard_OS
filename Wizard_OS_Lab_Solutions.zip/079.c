/* 1. Buggy version:  gcc -g -O0 -pthread 079.c -o racy -DBUGGY ; valgrind --tool=helgrind ./racy
      Helgrind reports "Possible data race during read/write of size 8 ... by thread #3 / #2" at the counter++ line.
   2. Fixed version:  gcc -g -O0 -pthread 079.c -o fixed ; valgrind --tool=helgrind ./fixed   -> ERROR SUMMARY: 0 errors
   Alternative: perf stat -e context-switches,cache-misses ./fixed   or   perf record -g ./fixed */
#include <stdio.h>
#include <pthread.h>
long counter = 0;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
void *work(void *a) {
    for (int i = 0; i < 100000; i++) {
#ifndef BUGGY
        pthread_mutex_lock(&lock);       /* FIX: protect the shared variable */
#endif
        counter++;
#ifndef BUGGY
        pthread_mutex_unlock(&lock);
#endif
    }
    return NULL;
}
int main(void) {
    pthread_t a, b;
    pthread_create(&a, NULL, work, NULL); pthread_create(&b, NULL, work, NULL);
    pthread_join(a, NULL); pthread_join(b, NULL);
    printf("counter = %ld\n", counter);
    return 0;
}
