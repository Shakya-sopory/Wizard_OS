#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
int main(void) {
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    if (pid == 0) {
        printf("Child : PID = %d, parent PID = %d\n", getpid(), getppid());
        sleep(1);
        printf("Child : finishing\n");
        exit(0);
    }
    printf("Parent: PID = %d, child PID = %d, waiting...\n", getpid(), pid);
    int status;
    wait(&status);
    printf("Parent: child exited with status %d. All work complete.\n", WEXITSTATUS(status));
    return 0;
}
