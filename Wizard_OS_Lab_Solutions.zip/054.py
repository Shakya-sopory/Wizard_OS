#!/usr/bin/env python3
"""Plot a Resource Allocation Graph. Input: edges such as  P1 R1  (request: P1 waits for R1)  and  R2 P1  (assignment: R2 held by P1).
Usage: python3 054.py edges.txt [out.png]   (one edge per line; omit the file to type edges, empty line to finish)"""
import sys
import networkx as nx
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def read_edges(path=None):
    lines = open(path).read().splitlines() if path else iter(lambda: input("edge (e.g. P1 R1): "), "")
    edges = []
    for line in lines:
        parts = line.split()
        if len(parts) == 2:
            edges.append((parts[0], parts[1]))
    return edges

def main():
    path = sys.argv[1] if len(sys.argv) > 1 else None
    out = sys.argv[2] if len(sys.argv) > 2 else "rag.png"
    edges = read_edges(path)
    g = nx.DiGraph(edges)
    procs = [v for v in g if v.upper().startswith("P")]
    ress = [v for v in g if v.upper().startswith("R")]
    pos = nx.spring_layout(g, seed=3)
    plt.figure(figsize=(7, 6))
    nx.draw_networkx_nodes(g, pos, nodelist=procs, node_shape="o", node_color="lightblue", node_size=900)
    nx.draw_networkx_nodes(g, pos, nodelist=ress, node_shape="s", node_color="lightgreen", node_size=900)
    nx.draw_networkx_labels(g, pos)
    nx.draw_networkx_edges(g, pos, arrows=True, arrowsize=20, node_size=900)
    cycles = list(nx.simple_cycles(g))
    plt.title("Resource Allocation Graph - " + ("CYCLE: " + " -> ".join(cycles[0]) if cycles else "no cycle"))
    plt.axis("off")
    plt.savefig(out, dpi=120, bbox_inches="tight")
    print("Saved", out, "| cycle:", cycles[0] if cycles else "none (for single-instance resources: no deadlock)")

if __name__ == "__main__":
    main()
