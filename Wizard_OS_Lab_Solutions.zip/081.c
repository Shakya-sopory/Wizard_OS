#include <stdio.h>
#include <stdlib.h>
int main(void) {
    int n, head;
    printf("Number of requests: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 100) return 1;
    int req[100];
    printf("Requests: "); for (int i = 0; i < n; i++) scanf("%d", &req[i]);
    printf("Initial head position: "); scanf("%d", &head);
    int total = 0, cur = head;
    printf("Seek sequence: %d", cur);
    for (int i = 0; i < n; i++) { total += abs(req[i] - cur); cur = req[i]; printf(" -> %d", cur); }   /* arrival order */
    printf("\nTotal head movement (FCFS) = %d cylinders\n", total);
    return 0;
}
