/* Two-level queue: Q1 = Round Robin (q = 4), Q2 = FCFS. Q2 runs only when Q1 is empty. Q1 has priority and
   a Q2 process is preempted (kept at its place) when a new Q1 process arrives. Each process has a queue id (1 or 2). */
#include <stdio.h>
#define Q 4
int main(void) {
    int n;
    printf("Number of processes: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 50) return 1;
    int at[50], bt[50], qid[50], rem[50], ct[50], inq1[50] = {0};
    for (int i = 0; i < n; i++) {
        printf("P%d arrival, burst, queue(1 or 2): ", i + 1);
        scanf("%d %d %d", &at[i], &bt[i], &qid[i]);
        rem[i] = bt[i];
    }
    int q1[5000], h = 0, t = 0, time = 0, done = 0;
    while (done < n) {
        for (int i = 0; i < n; i++)                         /* admit arrivals to Q1 */
            if (qid[i] == 1 && !inq1[i] && rem[i] > 0 && at[i] <= time) { q1[t++] = i; inq1[i] = 1; }
        if (h < t) {                                        /* Q1 not empty: Round Robin */
            int p = q1[h++];
            int run = rem[p] < Q ? rem[p] : Q;
            for (int k = 0; k < run; k++) {                 /* run one unit at a time to admit arrivals correctly */
                rem[p]--; time++;
                for (int i = 0; i < n; i++)
                    if (qid[i] == 1 && !inq1[i] && rem[i] > 0 && at[i] <= time) { q1[t++] = i; inq1[i] = 1; }
            }
            if (rem[p] > 0) q1[t++] = p; else { ct[p] = time; done++; }
        } else {                                            /* Q2: FCFS by arrival, one unit at a time so Q1 can preempt */
            int pick = -1;
            for (int i = 0; i < n; i++)
                if (qid[i] == 2 && rem[i] > 0 && at[i] <= time && (pick == -1 || at[i] < at[pick])) pick = i;
            if (pick == -1) { time++; continue; }
            rem[pick]--; time++;
            if (rem[pick] == 0) { ct[pick] = time; done++; }
        }
    }
    double st = 0, sw = 0;
    printf("\nPID  Q  AT  BT  CT  TAT  WT\n");
    for (int i = 0; i < n; i++) {
        int tat = ct[i] - at[i], wt = tat - bt[i];
        st += tat; sw += wt;
        printf("P%-3d %d %3d %3d %3d %4d %3d\n", i + 1, qid[i], at[i], bt[i], ct[i], tat, wt);
    }
    printf("Average turnaround = %.2f, average waiting = %.2f\n", st / n, sw / n);
    return 0;
}
