#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
int main(int argc, char *argv[]) {
    if (argc != 2) { fprintf(stderr, "Usage: %s <textfile>\n", argv[0]); return 1; }
    int fd = open(argv[1], O_RDONLY);
    if (fd < 0) { perror("open"); return 1; }
    if (lseek(fd, 100, SEEK_SET) < 0) { perror("lseek"); return 1; }        /* offset 100 = the 101st byte */
    char buf[51];
    ssize_t n = read(fd, buf, 50);
    if (n < 0) { perror("read"); return 1; }
    buf[n] = '\0';
    printf("Read %zd bytes starting at byte offset 100:\n%s\n", n, buf);
    close(fd);
    return 0;
}
