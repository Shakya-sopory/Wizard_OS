#include <stdio.h>
#include <stdlib.h>
int main(void) {
    int n, head;
    printf("Number of requests: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 100) return 1;
    int req[100], done[100] = {0};
    printf("Requests: "); for (int i = 0; i < n; i++) scanf("%d", &req[i]);
    printf("Initial head position: "); scanf("%d", &head);
    int total = 0, cur = head;
    printf("Seek sequence: %d", cur);
    for (int k = 0; k < n; k++) {
        int best = -1;
        for (int i = 0; i < n; i++)
            if (!done[i] && (best == -1 || abs(req[i] - cur) < abs(req[best] - cur))) best = i;   /* nearest request */
        done[best] = 1; total += abs(req[best] - cur); cur = req[best];
        printf(" -> %d", cur);
    }
    printf("\nTotal head movement (SSTF) = %d cylinders\n", total);
    return 0;
}
