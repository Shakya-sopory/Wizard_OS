/* usage: ./rr <quantum>   then enter n and (arrival, burst) pairs */
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[]) {
    if (argc != 2 || atoi(argv[1]) <= 0) { fprintf(stderr, "Usage: %s <time quantum>\n", argv[0]); return 1; }
    int q = atoi(argv[1]), n;
    printf("Number of processes: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 50) return 1;
    int at[50], bt[50], rem[50], ct[50], inq[50] = {0};
    for (int i = 0; i < n; i++) {
        printf("P%d arrival and burst time: ", i + 1);
        scanf("%d %d", &at[i], &bt[i]);
        rem[i] = bt[i];
    }
    int queue[5000], head = 0, tail = 0, time = 0, done = 0;
    /* start at the earliest arrival */
    int first = 0;
    for (int i = 1; i < n; i++) if (at[i] < at[first]) first = i;
    time = at[first]; queue[tail++] = first; inq[first] = 1;
    while (done < n) {
        if (head == tail) {                       /* queue empty: jump to next arrival */
            int nx = -1;
            for (int i = 0; i < n; i++) if (rem[i] > 0 && !inq[i] && (nx == -1 || at[i] < at[nx])) nx = i;
            time = at[nx]; queue[tail++] = nx; inq[nx] = 1;
        }
        int p = queue[head++];
        int run = rem[p] < q ? rem[p] : q;
        time += run; rem[p] -= run;
        for (int i = 0; i < n; i++)                /* add newly arrived processes first */
            if (!inq[i] && rem[i] > 0 && at[i] <= time) { queue[tail++] = i; inq[i] = 1; }
        if (rem[p] > 0) queue[tail++] = p;
        else { ct[p] = time; done++; }
    }
    double st = 0, sw = 0;
    printf("\nPID  AT  BT  CT  TAT  WT\n");
    for (int i = 0; i < n; i++) {
        int tat = ct[i] - at[i], wt = tat - bt[i];
        st += tat; sw += wt;
        printf("P%-3d %3d %3d %3d %4d %3d\n", i + 1, at[i], bt[i], ct[i], tat, wt);
    }
    printf("Quantum %d: average turnaround = %.2f, average waiting = %.2f\n", q, st / n, sw / n);
    return 0;
}
