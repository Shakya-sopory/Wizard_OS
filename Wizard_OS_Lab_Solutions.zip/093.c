#include <stdio.h>
#include <string.h>
#define DISK 32
int disk[DISK];                                   /* 0 = free, otherwise file id */
int create_file(int id, int size) {               /* first-fit search for a contiguous run */
    int run = 0;
    for (int i = 0; i < DISK; i++) {
        run = (disk[i] == 0) ? run + 1 : 0;
        if (run == size) {
            int start = i - size + 1;
            for (int j = start; j <= i; j++) disk[j] = id;
            printf("File %d (size %d) created at blocks %d-%d\n", id, size, start, i);
            return start;
        }
    }
    printf("File %d (size %d) cannot be created: no contiguous space (external fragmentation)\n", id, size);
    return -1;
}
void delete_file(int id) {
    for (int i = 0; i < DISK; i++) if (disk[i] == id) disk[i] = 0;        /* reset indices to 0 */
    printf("File %d deleted\n", id);
}
void show(void) { for (int i = 0; i < DISK; i++) printf("%d ", disk[i]); printf("\n"); }
int main(void) {
    create_file(1, 5); create_file(2, 8); create_file(3, 4); create_file(4, 6);
    show();
    delete_file(2); show();
    create_file(5, 10);                           /* needs 10, hole has only 8 */
    create_file(6, 7); show();
    return 0;
}
