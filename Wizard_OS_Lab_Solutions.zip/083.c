#include <stdio.h>
#include <stdlib.h>
static void sort(int *a, int n) { for (int i = 0; i < n - 1; i++) for (int j = 0; j < n - i - 1; j++) if (a[j] > a[j + 1]) { int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t; } }
int main(void) {
    int n, head, maxcyl, dir;
    printf("Number of requests: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 100) return 1;
    int req[100];
    printf("Requests: "); for (int i = 0; i < n; i++) scanf("%d", &req[i]);
    printf("Head position, highest cylinder number, direction (0 = towards 0, 1 = towards max): ");
    scanf("%d %d %d", &head, &maxcyl, &dir);
    sort(req, n);
    int total = 0, cur = head;
    printf("Seek sequence: %d", cur);
    if (dir == 1) {
        for (int i = 0; i < n; i++) if (req[i] >= head) { total += req[i] - cur; cur = req[i]; printf(" -> %d", cur); }
        if (cur != maxcyl) { total += maxcyl - cur; cur = maxcyl; printf(" -> %d", cur); }          /* go to the end */
        for (int i = n - 1; i >= 0; i--) if (req[i] < head) { total += cur - req[i]; cur = req[i]; printf(" -> %d", cur); }
    } else {
        for (int i = n - 1; i >= 0; i--) if (req[i] <= head) { total += cur - req[i]; cur = req[i]; printf(" -> %d", cur); }
        if (cur != 0) { total += cur; cur = 0; printf(" -> 0"); }
        for (int i = 0; i < n; i++) if (req[i] > head) { total += req[i] - cur; cur = req[i]; printf(" -> %d", cur); }
    }
    printf("\nTotal head movement (SCAN) = %d cylinders\n", total);
    return 0;
}
