#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
pthread_mutex_t lock1 = PTHREAD_MUTEX_INITIALIZER, lock2 = PTHREAD_MUTEX_INITIALIZER;
static void *worker(void *arg) {
    int id = (int)(long)arg;
    pthread_mutex_t *first = id == 1 ? &lock1 : &lock2, *second = id == 1 ? &lock2 : &lock1;
    unsigned seed = id * 7919;
    for (int attempt = 1; ; attempt++) {
        pthread_mutex_lock(first);
        usleep(1000);                                          /* widen the window */
        if (pthread_mutex_trylock(second) == 0) {
            printf("T%d acquired both locks on attempt %d\n", id, attempt);
            pthread_mutex_unlock(second); pthread_mutex_unlock(first);
            return NULL;
        }
        pthread_mutex_unlock(first);                           /* failed: release the first lock */
        printf("T%d attempt %d failed, backing off\n", id, attempt);
        usleep(1000 + rand_r(&seed) % 20000);                  /* random back-off prevents livelock */
    }
}
int main(void) {
    pthread_t a, b;
    pthread_create(&a, NULL, worker, (void *)1L); pthread_create(&b, NULL, worker, (void *)2L);
    pthread_join(a, NULL); pthread_join(b, NULL);
    printf("Both threads finished. Remove the random back-off to see a possible livelock.\n");
    return 0;
}
