#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#define CHAIRS 3
#define CUSTOMERS 10
sem_t customers, barber, mutex;
int waiting = 0, served = 0, turned_away = 0;
void *barber_thread(void *a) {
    while (1) {
        sem_wait(&customers);                              /* sleep until a customer arrives */
        sem_wait(&mutex); waiting--; sem_post(&mutex);
        sem_post(&barber);                                 /* invite the customer */
        printf("Barber is cutting hair\n");
        usleep(80000);
        served++;
    }
    return NULL;
}
void *customer_thread(void *a) {
    int id = (int)(long)a;
    sem_wait(&mutex);
    if (waiting < CHAIRS) {
        waiting++;
        printf("Customer %d sits in the waiting room (%d waiting)\n", id, waiting);
        sem_post(&customers); sem_post(&mutex);
        sem_wait(&barber);
        printf("Customer %d is getting a haircut\n", id);
    } else {
        turned_away++;
        printf("Customer %d leaves: no free chair\n", id);
        sem_post(&mutex);
    }
    return NULL;
}
int main(void) {
    sem_init(&customers, 0, 0); sem_init(&barber, 0, 0); sem_init(&mutex, 0, 1);
    pthread_t b, c[CUSTOMERS];
    pthread_create(&b, NULL, barber_thread, NULL);
    srand(1);
    for (long i = 0; i < CUSTOMERS; i++) { pthread_create(&c[i], NULL, customer_thread, (void *)(i + 1)); usleep(20000 + rand() % 40000); }
    for (int i = 0; i < CUSTOMERS; i++) pthread_join(c[i], NULL);
    sleep(1);
    printf("Served %d, turned away %d\n", served, turned_away);
    return 0;
}
