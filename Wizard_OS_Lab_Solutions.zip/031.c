/* Observe in another terminal:  top -p $(pgrep alloc2d)   -> VIRT jumps after malloc, RES grows only as the memory is touched */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define ROWS 20000
#define COLS 20000          /* 20000 x 20000 ints = 1.6 GB virtual; lower it if the machine has little RAM */
int main(void) {
    printf("PID %d. Press Enter to allocate...\n", getpid());
    getchar();
    int **a = malloc(ROWS * sizeof(int *));
    for (int i = 0; i < ROWS; i++) {
        a[i] = malloc(COLS * sizeof(int));
        if (!a[i]) { fprintf(stderr, "malloc failed at row %d\n", i); return 1; }
    }
    printf("Allocated (VIRT should be large, RES small). Press Enter to touch half of the rows...\n");
    getchar();
    for (int i = 0; i < ROWS / 2; i++) for (int j = 0; j < COLS; j++) a[i][j] = i + j;
    printf("Touched half (RES should have grown by about half of VIRT). Press Enter to free...\n");
    getchar();
    for (int i = 0; i < ROWS; i++) free(a[i]);
    free(a);
    printf("Freed.\n");
    return 0;
}
