#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
int main(int argc, char *argv[]) {
    if (argc != 2) { fprintf(stderr, "Usage: %s <textfile>\n", argv[0]); return 1; }
    int fd = open(argv[1], O_RDWR);
    if (fd < 0) { perror("open"); return 1; }
    struct stat st;
    if (fstat(fd, &st) < 0 || st.st_size == 0) { fprintf(stderr, "empty or unreadable file\n"); return 1; }
    char *p = mmap(NULL, st.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) { perror("mmap"); return 1; }
    for (off_t i = 0; i < st.st_size; i++) p[i] = toupper((unsigned char)p[i]);    /* edit through the pointer */
    if (msync(p, st.st_size, MS_SYNC) < 0) perror("msync");                          /* flush to the file */
    munmap(p, st.st_size);
    close(fd);
    printf("Converted %lld bytes to uppercase in place.\n", (long long)st.st_size);
    return 0;
}
