#include <stdio.h>
int main(void) {
    int page_table[8] = {5, 2, 7, 0, 3, 6, 1, 4};      /* page -> frame (hard-coded) */
    int npages = 8;
    unsigned page_size, logical;
    printf("Page size (bytes, power of 2): ");
    if (scanf("%u", &page_size) != 1 || page_size == 0 || (page_size & (page_size - 1))) { printf("Page size must be a power of 2\n"); return 1; }
    printf("Logical address: ");
    if (scanf("%u", &logical) != 1) return 1;
    unsigned page = logical / page_size, offset = logical % page_size;
    if (page >= (unsigned)npages) { printf("Page %u is outside the page table (invalid address)\n", page); return 1; }
    unsigned frame = page_table[page];
    unsigned physical = frame * page_size + offset;
    printf("Logical %u -> page %u, offset %u\n", logical, page, offset);
    printf("Page %u is in frame %u -> physical address = %u * %u + %u = %u\n", page, frame, frame, page_size, offset, physical);
    return 0;
}
