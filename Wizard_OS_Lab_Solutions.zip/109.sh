#!/bin/bash
# usage: ./109.sh <username>
[ $# -eq 1 ] || { echo "Usage: $0 <username>" >&2; exit 1; }
user=$1
if grep -q "^${user}:" /etc/passwd; then
    entry=$(grep "^${user}:" /etc/passwd)
    echo "User '$user' exists"
    echo "UID   : $(echo "$entry" | cut -d: -f3)"
    echo "Shell : $(echo "$entry" | cut -d: -f7)"
else
    echo "User '$user' does not exist" >&2; exit 1
fi
