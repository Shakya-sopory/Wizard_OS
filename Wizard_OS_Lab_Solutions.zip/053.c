#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#define N 5
pthread_mutex_t fork_[N], waiter = PTHREAD_MUTEX_INITIALIZER;
void *phil(void *arg) {
    int i = (int)(long)arg;
    for (int round = 0; round < 3; round++) {
        usleep(1000);
        pthread_mutex_lock(&waiter);                              /* ask the waiter: picking up forks is one atomic step */
        pthread_mutex_lock(&fork_[i]);
        pthread_mutex_lock(&fork_[(i + 1) % N]);
        pthread_mutex_unlock(&waiter);
        printf("Philosopher %d is eating (round %d)\n", i, round + 1);
        usleep(1000);
        pthread_mutex_unlock(&fork_[(i + 1) % N]);
        pthread_mutex_unlock(&fork_[i]);
    }
    return NULL;
}
int main(void) {
    pthread_t t[N];
    for (int i = 0; i < N; i++) pthread_mutex_init(&fork_[i], NULL);
    for (int i = 0; i < N; i++) pthread_create(&t[i], NULL, phil, (void *)(long)i);
    for (int i = 0; i < N; i++) pthread_join(t[i], NULL);
    printf("All philosophers finished: no deadlock (the waiter serialises fork pick-up).\n");
    return 0;
}
