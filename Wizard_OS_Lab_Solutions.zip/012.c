/* Ping-pong one byte between two processes over two pipes. Each round trip involves 2 context switches. */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/wait.h>
#define ROUNDS 100000
int main(void) {
    int p2c[2], c2p[2];
    if (pipe(p2c) < 0 || pipe(c2p) < 0) { perror("pipe"); return 1; }
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    char b = 'x';
    if (pid == 0) {
        close(p2c[1]); close(c2p[0]);
        for (int i = 0; i < ROUNDS; i++) {
            if (read(p2c[0], &b, 1) != 1) break;
            write(c2p[1], &b, 1);
        }
        return 0;
    }
    close(p2c[0]); close(c2p[1]);
    struct timeval s, e;
    gettimeofday(&s, NULL);
    for (int i = 0; i < ROUNDS; i++) {
        write(p2c[1], &b, 1);
        read(c2p[0], &b, 1);
    }
    gettimeofday(&e, NULL);
    wait(NULL);
    double us = (e.tv_sec - s.tv_sec) * 1e6 + (e.tv_usec - s.tv_usec);
    printf("%d round trips in %.0f us\n", ROUNDS, us);
    printf("Per round trip: %.3f us  ->  about %.3f us per context switch (2 switches per round trip,\n"
           "including pipe system call overhead, so this is an upper estimate)\n", us / ROUNDS, us / ROUNDS / 2);
    return 0;
}
