/* WARNING: this can freeze the machine. Run only in a VM/container with limited RAM and swap enabled.
   In another terminal:  vmstat 1     -> watch si (swap in) and so (swap out) and the wa column.
   Set MB to more than your physical RAM. Stop with Ctrl-C. */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(int argc, char *argv[]) {
    size_t mb = argc > 1 ? (size_t)atol(argv[1]) : 4096;
    size_t bytes = mb * 1024 * 1024;
    char *p = malloc(bytes);
    if (!p) { perror("malloc"); return 1; }
    printf("PID %d allocated %zu MB, writing randomly (Ctrl-C to stop)\n", getpid(), mb);
    unsigned long long x = 88172645463325252ULL;
    while (1) {
        x ^= x << 13; x ^= x >> 7; x ^= x << 17;                  /* xorshift random numbers */
        p[x % bytes] = (char)x;                                   /* random page each time */
    }
    return 0;
}
