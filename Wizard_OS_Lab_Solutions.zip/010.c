/* Preemptive priority scheduling, lower number = higher priority. Ties broken by earlier arrival. */
#include <stdio.h>
int main(void) {
    int n;
    printf("Number of processes: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 50) return 1;
    int at[50], bt[50], pr[50], rem[50], ct[50];
    for (int i = 0; i < n; i++) {
        printf("P%d arrival, burst, priority: ", i + 1);
        scanf("%d %d %d", &at[i], &bt[i], &pr[i]);
        rem[i] = bt[i];
    }
    int time = 0, done = 0;
    while (done < n) {
        int pick = -1;
        for (int i = 0; i < n; i++)
            if (rem[i] > 0 && at[i] <= time &&
                (pick == -1 || pr[i] < pr[pick] || (pr[i] == pr[pick] && at[i] < at[pick]))) pick = i;
        if (pick == -1) { time++; continue; }
        rem[pick]--; time++;
        if (rem[pick] == 0) { ct[pick] = time; done++; }
    }
    double st = 0, sw = 0;
    printf("\nPID  AT  BT  PR  CT  TAT  WT\n");
    for (int i = 0; i < n; i++) {
        int tat = ct[i] - at[i], wt = tat - bt[i];
        st += tat; sw += wt;
        printf("P%-3d %3d %3d %3d %3d %4d %3d\n", i + 1, at[i], bt[i], pr[i], ct[i], tat, wt);
    }
    printf("Average turnaround = %.2f, average waiting = %.2f, throughput = %.3f\n", st / n, sw / n, (double)n / time);
    return 0;
}
