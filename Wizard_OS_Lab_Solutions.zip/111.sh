#!/bin/bash
# /usr/local/bin/clean_tmp.sh : delete files in /tmp that were not accessed for 1 day (safe version; does not remove /tmp itself)
find /tmp -mindepth 1 -type f -atime +1 -delete 2>/dev/null
find /tmp -mindepth 1 -type d -empty -delete 2>/dev/null
echo "$(date): /tmp cleaned" >> /var/log/clean_tmp.log
# crontab entry (crontab -e) - every day at midnight:
#   0 0 * * * /usr/local/bin/clean_tmp.sh
