#!/bin/bash
# 16 random characters from letters, digits and symbols
tr -dc 'A-Za-z0-9!@#$%^&*()_+=-' < /dev/urandom | head -c 16; echo
