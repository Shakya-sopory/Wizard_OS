#include <stdio.h>
#include <pthread.h>
#define N 1000000
long counter = 0;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
void *inc(void *a) {
    for (int i = 0; i < N; i++) { pthread_mutex_lock(&lock); counter++; pthread_mutex_unlock(&lock); }
    return NULL;
}
int main(void) {
    pthread_t a, b;
    pthread_create(&a, NULL, inc, NULL); pthread_create(&b, NULL, inc, NULL);
    pthread_join(a, NULL); pthread_join(b, NULL);
    printf("Expected %d, got %ld %s\n", 2 * N, counter, counter == 2L * N ? "(correct)" : "(WRONG)");
    return 0;
}
