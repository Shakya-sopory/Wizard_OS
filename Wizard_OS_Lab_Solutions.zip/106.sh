#!/bin/bash
# Failed SSH password attempts per IP address (needs read access to the log: sudo)
LOG=${1:-/var/log/auth.log}
grep "Failed password" "$LOG" | grep -oE '[0-9]{1,3}(\.[0-9]{1,3}){3}' | sort | uniq -c | sort -rn
# one-liner: grep "Failed password" /var/log/auth.log | awk '{for(i=1;i<=NF;i++) if($i=="from") print $(i+1)}' | sort | uniq -c | sort -rn
