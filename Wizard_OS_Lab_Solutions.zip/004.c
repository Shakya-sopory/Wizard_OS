/* Run:  gcc 004.c -o zombie && ./zombie &
   In another terminal:  ps -o pid,ppid,stat,cmd -C zombie   -> the child shows STAT = Z (defunct) */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(void) {
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    if (pid == 0) {
        printf("Child %d exiting immediately\n", getpid());
        exit(0);                   /* child ends but nobody calls wait() */
    }
    printf("Parent %d sleeping 60 s without wait(); check: ps aux | grep Z\n", getpid());
    sleep(60);                     /* child stays a zombie during this time */
    return 0;
}
