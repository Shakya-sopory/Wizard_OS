#!/usr/bin/env python3
"""Checkpointing: saves a counter to checkpoint.txt every 5 seconds. Kill it (Ctrl-C or kill -9) and start it again: it resumes."""
import os, time

FILE = "checkpoint.txt"

def load():
    try:
        with open(FILE) as f:
            return int(f.read().strip())
    except (FileNotFoundError, ValueError):
        return 0

def save(value):
    tmp = FILE + ".tmp"
    with open(tmp, "w") as f:
        f.write(str(value))
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, FILE)                 # atomic rename: the checkpoint is never half written

counter = load()
print("Resuming from counter =", counter)
last_save = time.time()
while True:
    counter += 1                          # the "work"
    time.sleep(1)
    print("counter =", counter, flush=True)
    if time.time() - last_save >= 5:
        save(counter)
        last_save = time.time()
        print("   [checkpoint saved]", flush=True)
