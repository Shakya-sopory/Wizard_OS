#!/bin/bash
# usage: ./103.sh [directory]   renames every *.txt to *.bak
dir=${1:-.}
[ -d "$dir" ] || { echo "Not a directory: $dir" >&2; exit 1; }
shopt -s nullglob
for f in "$dir"/*.txt; do
    mv -- "$f" "${f%.txt}.bak"            # ${var%.txt} removes the suffix
    echo "Renamed $f -> ${f%.txt}.bak"
done
