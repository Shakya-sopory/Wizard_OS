#!/bin/bash
# buggy.sh - has intentional errors. Run:  bash -x buggy.sh 5 5
a=$1
b=$2
if [ $a == $b ]; then                  # fine for bash, but fails when a is empty: '[ == 5 ]' -> unary operator expected
    echo "equal"
fi
if [$a -gt $b ]; then                  # BUG: missing space after '[' -> command '[5' not found
    echo "greater"
fi
echo "a=$a b=$b"
# Run  bash -x buggy.sh 5 5  -> the trace shows '+ [ 5 == 5 ]' (true) then '+ [5 -gt 5 ]' and the error
# 'buggy.sh: line 8: [5: command not found', which pinpoints the failing line. With no arguments the trace shows
# '+ '[' == '' ']'' and the error 'unary operator expected'. Fix: quote variables ("$a") and put spaces inside [ ].
