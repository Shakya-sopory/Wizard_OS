#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#define N 1000000
#define T 4
static int arr[N];
typedef struct { int start, end; long long sum; } Part;
void *worker(void *a) {
    Part *p = a;
    p->sum = 0;
    for (int i = p->start; i < p->end; i++) p->sum += arr[i];
    return (void *)&p->sum;                 /* partial sum returned through pthread_exit/return */
}
int main(void) {
    for (int i = 0; i < N; i++) arr[i] = i % 100;
    pthread_t th[T]; Part parts[T];
    for (int t = 0; t < T; t++) {
        parts[t].start = t * (N / T);
        parts[t].end = (t == T - 1) ? N : (t + 1) * (N / T);
        pthread_create(&th[t], NULL, worker, &parts[t]);
    }
    long long total = 0;
    for (int t = 0; t < T; t++) {
        long long *r;
        pthread_join(th[t], (void **)&r);
        printf("Quadrant %d partial sum = %lld\n", t + 1, *r);
        total += *r;
    }
    long long check = 0;
    for (int i = 0; i < N; i++) check += arr[i];
    printf("Total = %lld (sequential check = %lld) %s\n", total, check, total == check ? "OK" : "MISMATCH");
    return 0;
}
