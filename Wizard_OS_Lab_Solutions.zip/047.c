#include <stdio.h>
#define MAX 10
int main(void) {
    int n, r;
    printf("Number of processes and resources: ");
    if (scanf("%d %d", &n, &r) != 2 || n <= 0 || r <= 0 || n > MAX || r > MAX) return 1;
    int alloc[MAX][MAX], req[MAX][MAX], wfg[MAX][MAX] = {{0}};
    printf("Allocation matrix (process x resource, 1 = holds):\n");
    for (int i = 0; i < n; i++) for (int j = 0; j < r; j++) scanf("%d", &alloc[i][j]);
    printf("Request matrix (process x resource, 1 = waiting for):\n");
    for (int i = 0; i < n; i++) for (int j = 0; j < r; j++) scanf("%d", &req[i][j]);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < r; j++)
            if (req[i][j])
                for (int k = 0; k < n; k++)
                    if (k != i && alloc[k][j]) wfg[i][k] = 1;        /* Pi waits for Pk, which holds Rj */
    printf("\nWait-For Graph adjacency matrix (row waits for column):\n    ");
    for (int k = 0; k < n; k++) printf("P%-2d", k);
    printf("\n");
    for (int i = 0; i < n; i++) { printf("P%-2d ", i); for (int k = 0; k < n; k++) printf("%-3d", wfg[i][k]); printf("\n"); }
    return 0;
}
