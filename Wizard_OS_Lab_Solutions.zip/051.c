/* May deadlock on purpose (usleep makes it happen quickly). Stop with Ctrl-C. */
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#define N 5
pthread_mutex_t fork_[N];
void *phil(void *arg) {
    int i = (int)(long)arg;
    for (int round = 0; round < 3; round++) {
        printf("Philosopher %d is thinking\n", i);
        usleep(1000);
        pthread_mutex_lock(&fork_[i]);                           /* left fork */
        printf("Philosopher %d picked up left fork %d\n", i, i);
        usleep(100000);                                          /* everybody holds the left fork by now */
        pthread_mutex_lock(&fork_[(i + 1) % N]);                 /* right fork */
        printf("Philosopher %d is eating\n", i);
        usleep(1000);
        pthread_mutex_unlock(&fork_[(i + 1) % N]);
        pthread_mutex_unlock(&fork_[i]);
    }
    return NULL;
}
int main(void) {
    pthread_t t[N];
    for (int i = 0; i < N; i++) pthread_mutex_init(&fork_[i], NULL);
    for (int i = 0; i < N; i++) pthread_create(&t[i], NULL, phil, (void *)(long)i);
    for (int i = 0; i < N; i++) pthread_join(t[i], NULL);       /* hangs: circular wait */
    return 0;
}
