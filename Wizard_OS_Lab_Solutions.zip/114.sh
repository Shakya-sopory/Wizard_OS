#!/bin/bash
# Top 10 largest files under /home
find /home -type f -exec du -h {} + 2>/dev/null | sort -rh | head -n 10
# alternative: find /home -type f -printf '%s %p\n' 2>/dev/null | sort -nr | head -10
