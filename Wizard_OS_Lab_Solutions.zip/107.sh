#!/bin/bash
# usage: ./107.sh grades.csv      columns: id,name,marks   (marks in the 3rd column, header in line 1)
awk -F',' 'NR>1 && $3 > 80 { print $2 }' "${1:-grades.csv}"
