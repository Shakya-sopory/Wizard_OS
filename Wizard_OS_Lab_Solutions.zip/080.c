/* Lock-free (Treiber) stack using C11 compare-and-swap. Note: it is subject to the ABA problem when nodes are freed and
   reused immediately; production code uses tagged pointers or hazard pointers. Here nodes are never freed while threads run. */
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <pthread.h>
typedef struct Node { int value; struct Node *next; } Node;
_Atomic(Node *) top = NULL;
void push(int v) {
    Node *n = malloc(sizeof *n); n->value = v;
    n->next = atomic_load(&top);
    while (!atomic_compare_exchange_weak(&top, &n->next, n)) ;      /* on failure n->next is refreshed with the current top */
}
int pop(int *out) {
    Node *old = atomic_load(&top);
    while (old && !atomic_compare_exchange_weak(&top, &old, old->next)) ;
    if (!old) return 0;
    *out = old->value;
    return 1;                                                       /* node leaked on purpose (ABA/ memory reclamation) */
}
atomic_long popped_sum = 0;
void *pusher(void *a) { long base = (long)a; for (int i = 1; i <= 10000; i++) push((int)(base + i)); return NULL; }
void *popper(void *a) { int v; for (int i = 0; i < 10000; i++) while (!pop(&v)) ; atomic_fetch_add(&popped_sum, v); return NULL; }
int main(void) {
    pthread_t p[4], c[4];
    for (long i = 0; i < 4; i++) pthread_create(&p[i], NULL, pusher, (void *)(i * 100000));
    for (int i = 0; i < 4; i++) pthread_create(&c[i], NULL, popper, NULL);
    for (int i = 0; i < 4; i++) pthread_join(p[i], NULL);
    for (int i = 0; i < 4; i++) pthread_join(c[i], NULL);
    int v, left = 0;
    while (pop(&v)) left++;
    printf("Stack empty after run: %s (leftover %d)\n", left == 0 ? "yes" : "no", left);
    return 0;
}
