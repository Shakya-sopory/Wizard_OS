#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
static void show(const char *p) {
    struct stat st;
    if (lstat(p, &st) < 0) { perror(p); return; }
    printf("%-12s inode %-10lu links %lu  type %s\n", p, (unsigned long)st.st_ino, (unsigned long)st.st_nlink, S_ISLNK(st.st_mode) ? "symlink" : "regular");
}
int main(void) {
    unlink("hard.txt"); unlink("soft.txt");
    int fd = open("orig.txt", O_CREAT | O_WRONLY | O_TRUNC, 0644);
    write(fd, "hello\n", 6); close(fd);
    if (link("orig.txt", "hard.txt") < 0) perror("link");
    if (symlink("orig.txt", "soft.txt") < 0) perror("symlink");
    show("orig.txt"); show("hard.txt"); show("soft.txt");
    printf("-> hard link shares the inode of the original; the symlink has its own inode.\n");
    unlink("orig.txt");
    printf("After deleting orig.txt: hard.txt %s, soft.txt %s\n",
           access("hard.txt", F_OK) == 0 ? "still works" : "broken", access("soft.txt", F_OK) == 0 ? "still works" : "dangling (broken)");
    unlink("hard.txt"); unlink("soft.txt");
    return 0;
}
