#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#define MAXARGS 64
int main(void) {
    char line[1024];
    while (1) {
        printf("mysh> ");
        fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) { printf("\n"); break; }   /* Ctrl-D exits */
        line[strcspn(line, "\n")] = '\0';
        char *args[MAXARGS];
        int n = 0;
        for (char *tok = strtok(line, " \t"); tok && n < MAXARGS - 1; tok = strtok(NULL, " \t")) args[n++] = tok;
        args[n] = NULL;
        if (n == 0) continue;
        if (strcmp(args[0], "exit") == 0) break;
        if (strcmp(args[0], "cd") == 0) {                 /* cd must run in the shell itself */
            if (n < 2 || chdir(args[1]) != 0) perror("cd");
            continue;
        }
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); continue; }
        if (pid == 0) {
            execvp(args[0], args);
            perror(args[0]);
            exit(127);
        }
        int status;
        waitpid(pid, &status, 0);
    }
    return 0;
}
