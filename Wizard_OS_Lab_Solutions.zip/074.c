#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#define WORKERS 4
#define TASKS 20
#define QSIZE 8
typedef struct { void (*fn)(void *); void *arg; } Task;
Task queue[QSIZE]; int head = 0, tail = 0, count = 0, shutdown_ = 0;
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t not_empty = PTHREAD_COND_INITIALIZER, not_full = PTHREAD_COND_INITIALIZER;
void submit(void (*fn)(void *), void *arg) {
    pthread_mutex_lock(&m);
    while (count == QSIZE) pthread_cond_wait(&not_full, &m);
    queue[tail] = (Task){fn, arg}; tail = (tail + 1) % QSIZE; count++;
    pthread_cond_signal(&not_empty);
    pthread_mutex_unlock(&m);
}
void *worker(void *a) {
    int id = (int)(long)a;
    while (1) {
        pthread_mutex_lock(&m);
        while (count == 0 && !shutdown_) pthread_cond_wait(&not_empty, &m);
        if (count == 0 && shutdown_) { pthread_mutex_unlock(&m); return NULL; }
        Task t = queue[head]; head = (head + 1) % QSIZE; count--;
        pthread_cond_signal(&not_full);
        pthread_mutex_unlock(&m);
        printf("Worker %d: ", id);
        t.fn(t.arg);
    }
}
void square(void *arg) { int n = (int)(long)arg; usleep(10000); printf("task %d -> %d\n", n, n * n); }
int main(void) {
    pthread_t w[WORKERS];
    for (long i = 0; i < WORKERS; i++) pthread_create(&w[i], NULL, worker, (void *)(i + 1));
    for (long i = 1; i <= TASKS; i++) submit(square, (void *)i);
    pthread_mutex_lock(&m); shutdown_ = 1; pthread_cond_broadcast(&not_empty); pthread_mutex_unlock(&m);
    for (int i = 0; i < WORKERS; i++) pthread_join(w[i], NULL);
    printf("All %d tasks done.\n", TASKS);
    return 0;
}
