#include <stdio.h>
int main(void) {
    int n;
    printf("Number of processes: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 100) return 1;
    int at[100], bt[100], ct[100], done[100] = {0};
    for (int i = 0; i < n; i++) {
        printf("P%d arrival and burst time: ", i + 1);
        scanf("%d %d", &at[i], &bt[i]);
    }
    int time = 0, finished = 0;
    double st = 0, sw = 0;
    while (finished < n) {
        int pick = -1;
        for (int i = 0; i < n; i++)             /* dynamic ready queue: only arrived, unfinished */
            if (!done[i] && at[i] <= time && (pick == -1 || bt[i] < bt[pick])) pick = i;
        if (pick == -1) { time++; continue; }  /* CPU idle */
        time += bt[pick];
        ct[pick] = time; done[pick] = 1; finished++;
    }
    printf("\nPID  AT  BT  CT  TAT  WT\n");
    for (int i = 0; i < n; i++) {
        int tat = ct[i] - at[i], wt = tat - bt[i];
        st += tat; sw += wt;
        printf("P%-3d %3d %3d %3d %4d %3d\n", i + 1, at[i], bt[i], ct[i], tat, wt);
    }
    printf("Average turnaround = %.2f, average waiting = %.2f\n", st / n, sw / n);
    return 0;
}
