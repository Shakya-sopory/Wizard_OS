#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(void) {
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    if (pid == 0) {
        printf("Child : PID %d, parent PID before = %d\n", getpid(), getppid());
        sleep(3);                  /* parent has exited by now */
        printf("Child : parent PID after  = %d (adopted by init/systemd)\n", getppid());
        return 0;
    }
    printf("Parent: PID %d exiting now, child is %d\n", getpid(), pid);
    exit(0);                       /* parent terminates first -> child becomes an orphan */
}
