#include <stdio.h>
#include <stdlib.h>
typedef struct Node { int page, ref; struct Node *next; } Node;
int main(void) {
    int nf, n;
    printf("Number of frames: ");
    if (scanf("%d", &nf) != 1 || nf <= 0 || nf > 50) return 1;
    printf("Length of reference string: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 200) return 1;
    int ref[200];
    printf("Reference string: ");
    for (int i = 0; i < n; i++) scanf("%d", &ref[i]);
    Node *first = NULL, *prev = NULL;                       /* circular linked list of frames */
    for (int i = 0; i < nf; i++) {
        Node *x = malloc(sizeof *x);
        x->page = -1; x->ref = 0; x->next = NULL;
        if (!first) first = x; else prev->next = x;
        prev = x;
    }
    prev->next = first;
    Node *hand = first;
    int faults = 0;
    for (int i = 0; i < n; i++) {
        Node *p = first; int hit = 0;
        do { if (p->page == ref[i]) { p->ref = 1; hit = 1; break; } p = p->next; } while (p != first);
        if (!hit) {
            faults++;
            while (hand->ref == 1) { hand->ref = 0; hand = hand->next; }   /* second chance */
            hand->page = ref[i]; hand->ref = 1;
            hand = hand->next;
        }
        printf("%3d : ", ref[i]);
        p = first;
        do { if (p->page < 0) printf(" -(0) "); else printf("%2d(%d) ", p->page, p->ref); p = p->next; } while (p != first);
        printf(hit ? " hit\n" : " FAULT\n");
    }
    printf("Total page faults (Clock) = %d\n", faults);
    return 0;
}
