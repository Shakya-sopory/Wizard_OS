/* Compile WITHOUT optimisation to see the race:  gcc -O0 -pthread 061.c -o race */
#include <stdio.h>
#include <pthread.h>
#define N 1000000
long counter = 0;
void *inc(void *a) { for (int i = 0; i < N; i++) counter++; return NULL; }    /* load, add, store: not atomic */
int main(void) {
    pthread_t a, b;
    pthread_create(&a, NULL, inc, NULL); pthread_create(&b, NULL, inc, NULL);
    pthread_join(a, NULL); pthread_join(b, NULL);
    printf("Expected %d, got %ld  (lost updates: %ld)\n", 2 * N, counter, 2L * N - counter);
    return 0;
}
