#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
pthread_mutex_t lock1 = PTHREAD_MUTEX_INITIALIZER, lock2 = PTHREAD_MUTEX_INITIALIZER;
/* Global order: lock1 is always acquired before lock2. A cycle would need some thread to hold lock2 and wait for
   lock1, which the rule forbids, so the circular-wait condition can never hold. */
void *worker(void *arg) {
    int id = (int)(long)arg;
    pthread_mutex_lock(&lock1); printf("T%d holds lock1\n", id);
    sleep(1);
    pthread_mutex_lock(&lock2); printf("T%d holds lock1 and lock2\n", id);
    pthread_mutex_unlock(&lock2); pthread_mutex_unlock(&lock1);
    return NULL;
}
int main(void) {
    pthread_t a, b;
    pthread_create(&a, NULL, worker, (void *)1L); pthread_create(&b, NULL, worker, (void *)2L);
    pthread_join(a, NULL); pthread_join(b, NULL);
    printf("Finished without deadlock.\n");
    return 0;
}
