/* Compile: gcc 060.c -o mqtimeout -lrt */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <fcntl.h>
#include <mqueue.h>
#include <unistd.h>
#include <sys/wait.h>
static int receive_with_timeout(mqd_t q, char *buf, size_t len, int seconds) {
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    ts.tv_sec += seconds;                                    /* absolute deadline */
    return mq_timedreceive(q, buf, len, NULL, &ts);
}
int main(void) {
    struct mq_attr at = {0, 4, 64, 0};
    mq_unlink("/q_ab"); mq_unlink("/q_ba");
    mqd_t ab = mq_open("/q_ab", O_CREAT | O_RDWR, 0600, &at);
    mqd_t ba = mq_open("/q_ba", O_CREAT | O_RDWR, 0600, &at);
    if (ab == (mqd_t)-1 || ba == (mqd_t)-1) { perror("mq_open"); return 1; }
    char buf[64];
    pid_t pid = fork();
    if (pid == 0) {
        if (receive_with_timeout(ab, buf, sizeof buf, 3) < 0) {
            fprintf(stderr, "B: %s after 3 s - aborting transaction\n", errno == ETIMEDOUT ? "timeout" : strerror(errno));
            return 1;
        }
        mq_send(ba, "hello from B", 13, 0);
        return 0;
    }
    if (receive_with_timeout(ba, buf, sizeof buf, 3) < 0) {
        fprintf(stderr, "A: %s after 3 s - aborting transaction\n", errno == ETIMEDOUT ? "timeout" : strerror(errno));
        wait(NULL);
        mq_unlink("/q_ab"); mq_unlink("/q_ba");
        return 1;
    }
    mq_send(ab, "hello from A", 13, 0);
    wait(NULL);
    return 0;
}
