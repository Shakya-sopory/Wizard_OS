/* Compile: gcc 059.c -o mqdead -lrt . Both processes block in mq_receive, each waiting for the other to send first. Stop with Ctrl-C. */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <mqueue.h>
#include <unistd.h>
#include <sys/wait.h>
int main(void) {
    struct mq_attr at = {0, 4, 64, 0};
    mq_unlink("/q_ab"); mq_unlink("/q_ba");
    mqd_t ab = mq_open("/q_ab", O_CREAT | O_RDWR, 0600, &at);   /* A -> B */
    mqd_t ba = mq_open("/q_ba", O_CREAT | O_RDWR, 0600, &at);   /* B -> A */
    if (ab == (mqd_t)-1 || ba == (mqd_t)-1) { perror("mq_open"); return 1; }
    char buf[64];
    pid_t pid = fork();
    if (pid == 0) {                                  /* process B */
        printf("B: waiting for a message from A\n");
        mq_receive(ab, buf, sizeof buf, NULL);       /* blocks forever */
        mq_send(ba, "hello from B", 13, 0);
        return 0;
    }
    printf("A: waiting for a message from B\n");
    mq_receive(ba, buf, sizeof buf, NULL);           /* blocks forever: circular wait on messages */
    mq_send(ab, "hello from A", 13, 0);
    wait(NULL);
    return 0;
}
