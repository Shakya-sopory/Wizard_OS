#!/bin/bash
hosts=("8.8.8.8" "1.1.1.1" "192.0.2.1" "localhost")
for ip in "${hosts[@]}"; do
    ping -c 3 -W 2 "$ip" > /dev/null 2>&1
    if [ $? -eq 0 ]; then echo "$ip: Host is UP"; else echo "$ip: Host is DOWN"; fi
done
