#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
sem_t rw_mutex, mutex;
int read_count = 0, shared = 0;
void *reader(void *arg) {
    int id = (int)(long)arg;
    sem_wait(&mutex);
    if (++read_count == 1) sem_wait(&rw_mutex);          /* first reader locks out writers */
    sem_post(&mutex);
    printf("Reader %d reads %d (readers now: %d)\n", id, shared, read_count);
    usleep(50000);
    sem_wait(&mutex);
    if (--read_count == 0) sem_post(&rw_mutex);          /* last reader lets writers in */
    sem_post(&mutex);
    return NULL;
}
void *writer(void *arg) {
    int id = (int)(long)arg;
    sem_wait(&rw_mutex);
    shared++;
    printf("Writer %d wrote %d (exclusive)\n", id, shared);
    usleep(50000);
    sem_post(&rw_mutex);
    return NULL;
}
int main(void) {
    sem_init(&rw_mutex, 0, 1); sem_init(&mutex, 0, 1);
    pthread_t r[5], w[2];
    for (long i = 0; i < 5; i++) { pthread_create(&r[i], NULL, reader, (void *)(i + 1)); usleep(10000);
        if (i == 1) pthread_create(&w[0], NULL, writer, (void *)1L);
        if (i == 3) pthread_create(&w[1], NULL, writer, (void *)2L); }
    for (int i = 0; i < 5; i++) pthread_join(r[i], NULL);
    pthread_join(w[0], NULL); pthread_join(w[1], NULL);
    return 0;
}
