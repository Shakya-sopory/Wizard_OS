#!/bin/bash
# usage: ./113.sh 12 + 5      (use \* for multiplication so the shell does not expand it)
if [ $# -ne 3 ]; then echo "Usage: $0 <num1> <operator> <num2>" >&2; exit 1; fi
a=$1; op=$2; b=$3
case $op in
    +) echo "$a + $b = $(echo "scale=4; $a + $b" | bc)" ;;
    -) echo "$a - $b = $(echo "scale=4; $a - $b" | bc)" ;;
    '*'|x) echo "$a * $b = $(echo "scale=4; $a * $b" | bc)" ;;
    /) if [ "$(echo "$b == 0" | bc)" = 1 ]; then echo "Error: division by zero" >&2; exit 1; fi
       echo "$a / $b = $(echo "scale=4; $a / $b" | bc)" ;;
    *) echo "Unknown operator: $op" >&2; exit 1 ;;
esac
