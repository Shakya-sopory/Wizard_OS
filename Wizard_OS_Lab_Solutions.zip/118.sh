#!/bin/bash
# Parents of zombie (Z) processes: these are the processes that never called wait()
ps -eo pid,ppid,stat,comm | awk '$3 ~ /^Z/ { print "Zombie PID " $1 " (" $4 ") -> parent PID " $2 }'
echo "Parents to investigate:"
ps -eo ppid,stat | awk '$2 ~ /^Z/ {print $1}' | sort -u
