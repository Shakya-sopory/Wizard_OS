#include <stdio.h>
#define DISK 32
typedef struct { int data; int next; } Block;      /* next = -1 : end of file, -2 : free */
Block disk[DISK];
int file_start[10];
int alloc_block(void) { for (int i = 0; i < DISK; i++) if (disk[i].next == -2) return i; return -1; }
void create_file(int f, int nblocks, int base) {
    int prev = -1;
    for (int k = 0; k < nblocks; k++) {
        int b = alloc_block();
        if (b < 0) { printf("Disk full\n"); return; }
        disk[b].data = base + k; disk[b].next = -1;
        if (prev < 0) file_start[f] = b; else disk[prev].next = b;      /* link the new block */
        prev = b;
    }
}
void print_file(int f) {
    printf("File %d: ", f);
    for (int b = file_start[f]; b != -1; b = disk[b].next) printf("[%d:data %d] -> ", b, disk[b].data);
    printf("EOF\n");
}
void delete_file(int f) { int b = file_start[f]; while (b != -1) { int n = disk[b].next; disk[b].next = -2; b = n; } }
int main(void) {
    for (int i = 0; i < DISK; i++) disk[i].next = -2;
    create_file(0, 4, 100); create_file(1, 3, 200); create_file(2, 4, 300);
    print_file(0); print_file(1);
    delete_file(1);
    create_file(3, 5, 400);               /* reuses the freed blocks, so the file becomes scattered */
    print_file(3);
    return 0;
}
