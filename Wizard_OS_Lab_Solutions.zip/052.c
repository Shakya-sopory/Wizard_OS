#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#define N 5
pthread_mutex_t fork_[N];
void *phil(void *arg) {
    int i = (int)(long)arg;
    int left = i, right = (i + 1) % N;
    int first = (i % 2 == 1) ? left : right;                    /* odd: left first, even: right first */
    int second = (i % 2 == 1) ? right : left;
    for (int round = 0; round < 3; round++) {
        usleep(1000);
        pthread_mutex_lock(&fork_[first]);
        usleep(10000);
        pthread_mutex_lock(&fork_[second]);
        printf("Philosopher %d is eating (round %d)\n", i, round + 1);
        usleep(1000);
        pthread_mutex_unlock(&fork_[second]);
        pthread_mutex_unlock(&fork_[first]);
    }
    return NULL;
}
int main(void) {
    pthread_t t[N];
    for (int i = 0; i < N; i++) pthread_mutex_init(&fork_[i], NULL);
    for (int i = 0; i < N; i++) pthread_create(&t[i], NULL, phil, (void *)(long)i);
    for (int i = 0; i < N; i++) pthread_join(t[i], NULL);
    printf("All philosophers finished: no deadlock.\n");
    return 0;
}
