#include <iostream>
#include <vector>
#include <map>
#include <set>
using namespace std;
const int TOTAL = 1024;                         // total memory in KB (power of 2)
map<int, set<int>> freeList;                    // block size -> set of start addresses
map<int, pair<int,int>> allocated;              // start address -> (requested, block size)
int roundUp(int n) { int s = 1; while (s < n) s <<= 1; return s; }
void show() {
    cout << "  Free lists:";
    for (auto &e : freeList) if (!e.second.empty()) { cout << " [" << e.first << "K:"; for (int a : e.second) cout << " @" << a; cout << "]"; }
    cout << "\n";
}
int allocate(int req) {
    int size = roundUp(req), s = size;
    while (s <= TOTAL && freeList[s].empty()) s <<= 1;       // find smallest free block that is big enough
    if (s > TOTAL) { cout << "Allocation of " << req << "K failed\n"; return -1; }
    int addr = *freeList[s].begin(); freeList[s].erase(freeList[s].begin());
    while (s > size) {                                       // split down to the needed size
        s >>= 1;
        cout << "  split block into two " << s << "K buddies @" << addr << " and @" << addr + s << "\n";
        freeList[s].insert(addr + s);
    }
    allocated[addr] = {req, size};
    cout << "Allocated " << req << "K -> block of " << size << "K at " << addr << " (internal fragmentation " << size - req << "K)\n";
    return addr;
}
void release(int addr) {
    if (!allocated.count(addr)) { cout << "Invalid free\n"; return; }
    int size = allocated[addr].second; allocated.erase(addr);
    cout << "Freed block of " << size << "K at " << addr << "\n";
    while (size < TOTAL) {
        int buddy = addr ^ size;                             // buddy address
        if (freeList[size].count(buddy)) {                   // coalesce
            freeList[size].erase(buddy);
            addr = min(addr, buddy); size <<= 1;
            cout << "  coalesced into " << size << "K block at " << addr << "\n";
        } else break;
    }
    freeList[size].insert(addr);
}
int main() {
    freeList[TOTAL].insert(0);
    int a = allocate(100); show();
    int b = allocate(240); show();
    int c = allocate(60);  show();
    release(a); show();
    release(c); show();
    release(b); show();
    return 0;
}
