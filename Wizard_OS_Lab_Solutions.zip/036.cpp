#include <iostream>
#include <unordered_map>
#include <vector>
#include <utility>
using namespace std;
struct Key { int pid, page; bool operator==(const Key &o) const { return pid == o.pid && page == o.page; } };
struct KeyHash { size_t operator()(const Key &k) const { return hash<long long>()(((long long)k.pid << 32) ^ k.page); } };
int main() {
    const int FRAMES = 4;
    unordered_map<Key, int, KeyHash> ipt;           // (pid, page) -> frame : one entry per physical frame
    vector<Key> owner(FRAMES, Key{-1, -1});         // frame -> (pid, page)
    int nextFrame = 0, faults = 0;
    vector<pair<int,int>> refs = {{1,0},{1,1},{2,0},{1,0},{2,3},{3,1},{2,0},{1,1},{3,1}};
    for (auto &r : refs) {
        Key k{r.first, r.second};
        auto it = ipt.find(k);
        if (it != ipt.end()) { cout << "(" << r.first << "," << r.second << ") -> frame " << it->second << " (hit)\n"; continue; }
        faults++;
        int f = nextFrame;                         // FIFO replacement of frames
        nextFrame = (nextFrame + 1) % FRAMES;
        if (owner[f].pid != -1) ipt.erase(owner[f]);
        owner[f] = k; ipt[k] = f;
        cout << "(" << r.first << "," << r.second << ") -> frame " << f << " (fault, loaded)\n";
    }
    cout << "Page faults: " << faults << "\n";
    return 0;
}
