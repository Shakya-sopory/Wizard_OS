/* Runs First-Fit and Best-Fit on the same input and compares the leftover holes. */
#include <stdio.h>
#include <string.h>
static void run(const char *name, int nb, int *block, int np, int *req, int best) {
    int fr[50]; memcpy(fr, block, nb * sizeof(int));
    int unalloc = 0;
    printf("\n%s:\n", name);
    for (int i = 0; i < np; i++) {
        int f = -1;
        for (int j = 0; j < nb; j++) {
            if (fr[j] < req[i]) continue;
            if (!best) { f = j; break; }
            if (f == -1 || fr[j] < fr[f]) f = j;           /* smallest block that fits */
        }
        if (f < 0) { printf("  P%d (%d) not allocated\n", i + 1, req[i]); unalloc++; }
        else { fr[f] -= req[i]; printf("  P%d (%d) -> block %d, hole left %d\n", i + 1, req[i], f + 1, fr[f]); }
    }
    int total = 0, small = 0, maxreq = 0;
    for (int i = 0; i < np; i++) if (req[i] > maxreq) maxreq = req[i];
    for (int j = 0; j < nb; j++) { total += fr[j]; if (fr[j] > 0 && fr[j] < maxreq) small += fr[j]; }
    printf("  free total = %d, in holes smaller than the largest request (%d) = %d, unallocated processes = %d\n",
           total, maxreq, small, unalloc);
}
int main(void) {
    int nb, np, block[50], req[50];
    printf("Number of blocks: ");
    if (scanf("%d", &nb) != 1 || nb <= 0 || nb > 50) return 1;
    printf("Block sizes: "); for (int i = 0; i < nb; i++) scanf("%d", &block[i]);
    printf("Number of processes: ");
    if (scanf("%d", &np) != 1 || np <= 0 || np > 50) return 1;
    printf("Process sizes: "); for (int i = 0; i < np; i++) scanf("%d", &req[i]);
    run("First-Fit", nb, block, np, req, 0);
    run("Best-Fit", nb, block, np, req, 1);
    printf("\nCompare the 'holes smaller than the largest request' lines: those are the unusable fragments.\n");
    return 0;
}
