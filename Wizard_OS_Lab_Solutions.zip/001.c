#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
int main(void) {
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    if (pid == 0) {
        printf("Child : PID = %d, parent PID = %d\n", getpid(), getppid());
    } else {
        printf("Parent: PID = %d, child PID = %d\n", getpid(), pid);
    }
    return 0;
}
