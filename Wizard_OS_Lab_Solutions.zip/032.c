/* Compile: gcc -O0 032.c -o locality ; run: time ./locality row   and   time ./locality col */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define N 10000
int main(int argc, char *argv[]) {
    if (argc != 2) { fprintf(stderr, "Usage: %s row|col\n", argv[0]); return 1; }
    int *m = malloc((size_t)N * N * sizeof(int));
    if (!m) { perror("malloc"); return 1; }
    memset(m, 1, (size_t)N * N * sizeof(int));                 /* touch all pages first */
    long long sum = 0;
    clock_t s = clock();
    if (strcmp(argv[1], "row") == 0) {
        for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) sum += m[(size_t)i * N + j];     /* sequential access */
    } else {
        for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) sum += m[(size_t)i * N + j];     /* stride of N ints */
    }
    printf("%s order: sum = %lld, time = %.2f s\n", argv[1], sum, (double)(clock() - s) / CLOCKS_PER_SEC);
    free(m);
    return 0;
}
