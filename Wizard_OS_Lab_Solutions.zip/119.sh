#!/bin/bash
{
    echo "Starting at $(date)"
    ls /etc/hostname
    ls /nonexistent_path
    echo "uname: $(uname -s)"
    cat /no/such/file
} > success.out 2> error.err
echo "Done. Normal output is in success.out and errors are in error.err (nothing printed on the terminal)."
