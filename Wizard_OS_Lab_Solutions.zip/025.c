#include <stdio.h>
int main(void) {
    int nb, np;
    printf("Number of blocks: ");
    if (scanf("%d", &nb) != 1 || nb <= 0 || nb > 50) return 1;
    int block[50], free_[50];
    printf("Block sizes: ");
    for (int i = 0; i < nb; i++) { scanf("%d", &block[i]); free_[i] = block[i]; }
    printf("Number of processes: ");
    if (scanf("%d", &np) != 1 || np <= 0 || np > 50) return 1;
    int req[50];
    printf("Process sizes: ");
    for (int i = 0; i < np; i++) scanf("%d", &req[i]);
    printf("\nProcess  Size  Block  (remaining in block)\n");
    for (int i = 0; i < np; i++) {
        int found = -1;
        for (int j = 0; j < nb; j++) if (free_[j] >= req[i]) { found = j; break; }   /* first block that fits */
        if (found >= 0) { free_[found] -= req[i]; printf("P%-7d %-5d %-6d (%d left)\n", i + 1, req[i], found + 1, free_[found]); }
        else printf("P%-7d %-5d not allocated\n", i + 1, req[i]);
    }
    int total = 0;
    for (int j = 0; j < nb; j++) total += free_[j];
    printf("Total free memory left = %d\n", total);
    return 0;
}
