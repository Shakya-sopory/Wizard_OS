#!/bin/bash
read -p "Enter your name: " name
echo "Hello, ${name:-stranger}! Welcome."
echo "Current date and time: $(date '+%A, %d %B %Y %H:%M:%S')"
echo "Files in $(pwd):"
ls -l
