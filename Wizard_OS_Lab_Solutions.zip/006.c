#include <stdio.h>
int main(void) {
    int n;
    printf("Number of processes: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 100) return 1;
    int at[100], bt[100], ct[100], tat[100], wt[100], id[100];
    for (int i = 0; i < n; i++) {
        id[i] = i + 1;
        printf("P%d arrival and burst time: ", i + 1);
        scanf("%d %d", &at[i], &bt[i]);
    }
    /* sort by arrival time (FCFS order) */
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (at[j] > at[j + 1]) {
                int t;
                t = at[j]; at[j] = at[j + 1]; at[j + 1] = t;
                t = bt[j]; bt[j] = bt[j + 1]; bt[j + 1] = t;
                t = id[j]; id[j] = id[j + 1]; id[j + 1] = t;
            }
    int time = 0; double st = 0, sw = 0;
    printf("\nPID  AT  BT  CT  TAT  WT\n");
    for (int i = 0; i < n; i++) {
        if (time < at[i]) time = at[i];        /* CPU idle until arrival */
        time += bt[i];
        ct[i] = time;
        tat[i] = ct[i] - at[i];
        wt[i] = tat[i] - bt[i];
        st += tat[i]; sw += wt[i];
        printf("P%-3d %3d %3d %3d %4d %3d\n", id[i], at[i], bt[i], ct[i], tat[i], wt[i]);
    }
    printf("Average turnaround = %.2f, average waiting = %.2f\n", st / n, sw / n);
    return 0;
}
