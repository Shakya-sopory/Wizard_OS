#include <stdio.h>
int main(void) {
    int nb, np, block[50], fr[50], req[50];
    printf("Number of blocks: ");
    if (scanf("%d", &nb) != 1 || nb <= 0 || nb > 50) return 1;
    printf("Block sizes: "); for (int i = 0; i < nb; i++) { scanf("%d", &block[i]); fr[i] = block[i]; }
    printf("Number of processes: ");
    if (scanf("%d", &np) != 1 || np <= 0 || np > 50) return 1;
    printf("Process sizes: "); for (int i = 0; i < np; i++) scanf("%d", &req[i]);
    for (int i = 0; i < np; i++) {
        int f = -1;
        for (int j = 0; j < nb; j++) if (fr[j] >= req[i] && (f == -1 || fr[j] > fr[f])) f = j;   /* largest hole */
        if (f < 0) printf("P%d (%d): not allocated\n", i + 1, req[i]);
        else { fr[f] -= req[i]; printf("P%d (%d): block %d, hole left %d\n", i + 1, req[i], f + 1, fr[f]); }
    }
    int total = 0, largest = 0;
    for (int j = 0; j < nb; j++) { total += fr[j]; if (fr[j] > largest) largest = fr[j]; }
    printf("Total free memory = %d, largest single hole = %d\n", total, largest);
    printf("External fragmentation (free memory outside the largest hole) = %d\n", total - largest);
    return 0;
}
