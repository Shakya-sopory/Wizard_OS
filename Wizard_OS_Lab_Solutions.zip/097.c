#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
int main(int argc, char *argv[]) {
    if (argc != 2) { fprintf(stderr, "Usage: %s <file>\n", argv[0]); return 1; }
    int fd = open(argv[1], O_RDWR);
    if (fd < 0) { perror("open"); return 1; }
    struct stat st;
    if (fstat(fd, &st) < 0) { perror("fstat"); return 1; }
    off_t half = st.st_size / 2;
    if (ftruncate(fd, half) < 0) { perror("ftruncate"); return 1; }
    printf("Truncated %s from %lld to %lld bytes.\n", argv[1], (long long)st.st_size, (long long)half);
    close(fd);
    return 0;
}
