#include <stdio.h>
#define MAX 10
int n, g[MAX][MAX], removed[MAX], color[MAX];
static int dfs(int u) {
    color[u] = 1;
    for (int v = 0; v < n; v++) {
        if (!g[u][v] || removed[v]) continue;
        if (color[v] == 1) return 1;
        if (color[v] == 0 && dfs(v)) return 1;
    }
    color[u] = 2;
    return 0;
}
static int has_cycle(void) {
    for (int i = 0; i < n; i++) color[i] = 0;
    for (int i = 0; i < n; i++) if (!removed[i] && color[i] == 0 && dfs(i)) return 1;
    return 0;
}
static int out_degree(int u) { int d = 0; for (int v = 0; v < n; v++) if (g[u][v] && !removed[v]) d++; return d; }
int main(void) {
    printf("Number of processes: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > MAX) return 1;
    printf("Wait-For Graph adjacency matrix:\n");
    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) scanf("%d", &g[i][j]);
    while (has_cycle()) {
        int victim = -1, best = -1;
        for (int i = 0; i < n; i++) if (!removed[i] && out_degree(i) > best) { best = out_degree(i); victim = i; }
        removed[victim] = 1;                                     /* terminate the victim */
        printf("Cycle found: terminating P%d (out-degree %d)\n", victim, best);
    }
    printf("Deadlock resolved. Remaining processes:");
    for (int i = 0; i < n; i++) if (!removed[i]) printf(" P%d", i);
    printf("\n");
    return 0;
}
