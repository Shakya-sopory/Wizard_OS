#include <stdio.h>
#include <time.h>
#include <sys/stat.h>
int main(int argc, char *argv[]) {
    if (argc != 2) { fprintf(stderr, "Usage: %s <file>\n", argv[0]); return 1; }
    struct stat st;
    if (stat(argv[1], &st) < 0) { perror("stat"); return 1; }
    char tbuf[64];
    strftime(tbuf, sizeof tbuf, "%Y-%m-%d %H:%M:%S", localtime(&st.st_mtime));
    printf("File          : %s\nInode number  : %lu\nSize          : %lld bytes\nLast modified : %s\n",
           argv[1], (unsigned long)st.st_ino, (long long)st.st_size, tbuf);
    return 0;
}
