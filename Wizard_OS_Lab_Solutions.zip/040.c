/* Observe in another terminal while the program pauses:
     grep -E 'Rss|Shared|Private' /proc/<child pid>/smaps_rollup      (or pmap -x <pid>, or top's SHR column)
   Before the write: the child's pages are Shared_Clean / Shared_Dirty with the parent.
   After the write:  Private_Dirty grows by the size of the array (copy-on-write copies the pages). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#define SIZE (200UL * 1024 * 1024)
static void show(const char *tag) {
    char cmd[128];
    snprintf(cmd, sizeof cmd, "grep -E 'Rss|Shared_|Private_' /proc/%d/smaps_rollup", getpid());
    printf("---- %s (PID %d) ----\n", tag, getpid());
    fflush(stdout);
    system(cmd);
}
int main(void) {
    char *a = malloc(SIZE);
    if (!a) { perror("malloc"); return 1; }
    memset(a, 1, SIZE);                                  /* parent touches all pages */
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    if (pid == 0) {
        sleep(1);
        show("child BEFORE write (pages shared with parent)");
        memset(a, 2, SIZE);                              /* write -> copy-on-write page copies */
        show("child AFTER write (private copies made)");
        return 0;
    }
    wait(NULL);
    return 0;
}
