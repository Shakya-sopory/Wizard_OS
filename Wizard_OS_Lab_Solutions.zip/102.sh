#!/bin/bash
# usage: ./102.sh <path>
if [ $# -ne 1 ]; then echo "Usage: $0 <path>" >&2; exit 1; fi
p="$1"
if [ ! -e "$p" ]; then
    echo "Error: '$p' does not exist" >&2; exit 2
elif [ -f "$p" ]; then
    echo "'$p' is a regular file ($(wc -c < "$p") bytes)"
elif [ -d "$p" ]; then
    count=$(find "$p" -maxdepth 1 -type f | wc -l)
    echo "'$p' is a directory containing $count file(s)"
else
    echo "'$p' is neither a regular file nor a directory"
fi
