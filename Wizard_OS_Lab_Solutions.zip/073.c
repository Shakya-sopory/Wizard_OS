#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
typedef struct { int value; pthread_mutex_t m; pthread_cond_t cv; } my_sem_t;
void my_sem_init(my_sem_t *s, int v) { s->value = v; pthread_mutex_init(&s->m, NULL); pthread_cond_init(&s->cv, NULL); }
void my_sem_wait(my_sem_t *s) {
    pthread_mutex_lock(&s->m);
    while (s->value <= 0) pthread_cond_wait(&s->cv, &s->m);   /* block while no resource is available */
    s->value--;
    pthread_mutex_unlock(&s->m);
}
void my_sem_post(my_sem_t *s) {
    pthread_mutex_lock(&s->m);
    s->value++;
    pthread_cond_signal(&s->cv);                              /* wake one waiter */
    pthread_mutex_unlock(&s->m);
}
/* Demo: semaphore with 2 permits shared by 5 threads. */
my_sem_t sem;
int inside = 0, max_inside = 0;
pthread_mutex_t cm = PTHREAD_MUTEX_INITIALIZER;
void *worker(void *a) {
    int id = (int)(long)a;
    my_sem_wait(&sem);
    pthread_mutex_lock(&cm); inside++; if (inside > max_inside) max_inside = inside; pthread_mutex_unlock(&cm);
    printf("Thread %d in the critical region\n", id);
    usleep(100000);
    pthread_mutex_lock(&cm); inside--; pthread_mutex_unlock(&cm);
    my_sem_post(&sem);
    return NULL;
}
int main(void) {
    my_sem_init(&sem, 2);
    pthread_t t[5];
    for (long i = 0; i < 5; i++) pthread_create(&t[i], NULL, worker, (void *)(i + 1));
    for (int i = 0; i < 5; i++) pthread_join(t[i], NULL);
    printf("Max threads inside at the same time: %d (limit 2)\n", max_inside);
    return 0;
}
