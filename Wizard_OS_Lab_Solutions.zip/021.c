#include <stdio.h>
int main(void) {
    int nf, n;
    printf("Number of frames: ");
    if (scanf("%d", &nf) != 1 || nf <= 0 || nf > 50) return 1;
    printf("Length of reference string: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 200) return 1;
    int ref[200], frame[50], next = 0, faults = 0;
    printf("Reference string: ");
    for (int i = 0; i < n; i++) scanf("%d", &ref[i]);
    for (int i = 0; i < nf; i++) frame[i] = -1;
    for (int i = 0; i < n; i++) {
        int hit = 0;
        for (int j = 0; j < nf; j++) if (frame[j] == ref[i]) { hit = 1; break; }
        if (!hit) { frame[next] = ref[i]; next = (next + 1) % nf; faults++; }   /* replace the oldest page */
        printf("%3d : ", ref[i]);
        for (int j = 0; j < nf; j++) { if (frame[j] < 0) printf(" - "); else printf("%2d ", frame[j]); }
        printf(hit ? " hit\n" : " FAULT\n");
    }
    printf("Total page faults (FIFO) = %d\n", faults);
    return 0;
}
