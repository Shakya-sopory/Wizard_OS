#!/bin/bash
# usage: ./procstat.sh <pid>   - show user-mode and kernel-mode CPU time from /proc/<pid>/stat
if [ $# -ne 1 ]; then echo "Usage: $0 <pid>" >&2; exit 1; fi
PID=$1
if [ ! -r "/proc/$PID/stat" ]; then echo "No such process or not readable: $PID" >&2; exit 2; fi
# The command name (field 2) may contain spaces, so strip everything up to the last ')' first.
STAT=$(cat /proc/$PID/stat)
REST=${STAT##*) }                       # fields from 3 onward
set -- $REST                            # $1 = field 3 (state) ... field N = $(N-2)
STATE=$1
UTIME=${12}                             # field 14
STIME=${13}                             # field 15
HZ=$(getconf CLK_TCK)
echo "PID $PID  state $STATE"
echo "User-mode   time: $UTIME ticks = $(echo "scale=2; $UTIME / $HZ" | bc) s"
echo "Kernel-mode time: $STIME ticks = $(echo "scale=2; $STIME / $HZ" | bc) s"
