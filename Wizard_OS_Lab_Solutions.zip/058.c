/* Strict two-phase locking simulation: each transaction takes ALL its locks in the growing phase (in a fixed
   order to avoid deadlock), runs, then releases everything at commit. */
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#define ITEMS 3
pthread_rwlock_t lock_[ITEMS];
int data[ITEMS] = {100, 200, 300};
typedef struct { int id; int reads[ITEMS]; int writes[ITEMS]; } Txn;     /* 1 = needs that item */
void *txn(void *arg) {
    Txn *t = arg;
    for (int i = 0; i < ITEMS; i++) {                                    /* growing phase, ascending item order */
        if (t->writes[i]) { pthread_rwlock_wrlock(&lock_[i]); printf("T%d: X-lock item %d\n", t->id, i); }
        else if (t->reads[i]) { pthread_rwlock_rdlock(&lock_[i]); printf("T%d: S-lock item %d\n", t->id, i); }
    }
    int sum = 0;                                                         /* the transaction body */
    for (int i = 0; i < ITEMS; i++) if (t->reads[i]) sum += data[i];
    usleep(100000);
    for (int i = 0; i < ITEMS; i++) if (t->writes[i]) data[i] += sum % 7 + 1;
    printf("T%d: commit (read sum %d)\n", t->id, sum);
    for (int i = ITEMS - 1; i >= 0; i--)                                 /* shrinking phase: all at commit */
        if (t->reads[i] || t->writes[i]) pthread_rwlock_unlock(&lock_[i]);
    return NULL;
}
int main(void) {
    for (int i = 0; i < ITEMS; i++) pthread_rwlock_init(&lock_[i], NULL);
    Txn t[3] = {
        {1, {1, 1, 0}, {0, 0, 1}},
        {2, {0, 1, 1}, {1, 0, 0}},
        {3, {1, 0, 0}, {0, 1, 0}},
    };
    pthread_t th[3];
    for (int i = 0; i < 3; i++) pthread_create(&th[i], NULL, txn, &t[i]);
    for (int i = 0; i < 3; i++) pthread_join(th[i], NULL);
    printf("Final data: %d %d %d\n", data[0], data[1], data[2]);
    return 0;
}
