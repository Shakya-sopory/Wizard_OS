#include <stdio.h>
#include <stdbool.h>
#include <pthread.h>
#include <unistd.h>
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cv = PTHREAD_COND_INITIALIZER;
bool ready = false;
void *thread_a(void *x) {
    pthread_mutex_lock(&m);
    while (!ready) {                                  /* loop guards against spurious wake-ups and lost signals */
        printf("A: waiting for the condition...\n");
        pthread_cond_wait(&cv, &m);                   /* atomically releases m and sleeps */
    }
    printf("A: condition is true, continuing\n");
    pthread_mutex_unlock(&m);
    return NULL;
}
void *thread_b(void *x) {
    sleep(2);
    pthread_mutex_lock(&m);
    ready = true;
    printf("B: flag set, signalling A\n");
    pthread_cond_signal(&cv);
    pthread_mutex_unlock(&m);
    return NULL;
}
int main(void) {
    pthread_t a, b;
    pthread_create(&a, NULL, thread_a, NULL); pthread_create(&b, NULL, thread_b, NULL);
    pthread_join(a, NULL); pthread_join(b, NULL);
    return 0;
}
