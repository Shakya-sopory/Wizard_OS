#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/wait.h>
int main(void) {
    int fd[2];
    if (pipe(fd) < 0) { perror("pipe"); return 1; }
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    if (pid == 0) {                              /* child: reads from the pipe */
        close(fd[1]);
        char buf[256];
        ssize_t n = read(fd[0], buf, sizeof buf - 1);
        if (n < 0) { perror("read"); exit(1); }
        buf[n] = '\0';
        for (int i = 0; i < n; i++) buf[i] = toupper((unsigned char)buf[i]);
        printf("Child received and converted: %s\n", buf);
        close(fd[0]);
        exit(0);
    }
    close(fd[0]);                                /* parent: writes into the pipe */
    const char *msg = "hello from the parent process";
    write(fd[1], msg, strlen(msg));
    close(fd[1]);
    wait(NULL);
    return 0;
}
