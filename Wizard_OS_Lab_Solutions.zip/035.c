#include <stdio.h>
int main(void) {
    int base[5] = {1400, 6300, 4300, 3200, 4700};
    int limit[5] = {1000, 400, 400, 1100, 1000};
    int ns = 5;
    int seg, off;
    printf("Segment table:\nseg  base  limit\n");
    for (int i = 0; i < ns; i++) printf("%3d %5d %6d\n", i, base[i], limit[i]);
    while (1) {
        printf("\nEnter segment and offset (negative segment to quit): ");
        if (scanf("%d %d", &seg, &off) != 2 || seg < 0) break;
        if (seg >= ns) { printf("Segmentation fault: segment %d does not exist\n", seg); continue; }
        if (off < 0 || off >= limit[seg]) { printf("Segmentation fault: offset %d >= limit %d (trap to OS)\n", off, limit[seg]); continue; }
        printf("Legal: physical address = base %d + offset %d = %d\n", base[seg], off, base[seg] + off);
    }
    return 0;
}
