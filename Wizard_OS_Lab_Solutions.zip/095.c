#include <stdio.h>
#define CACHE 4
int blk[CACHE], age[CACHE], used = 0, clock_ = 0, hits = 0, misses = 0;
void read_block(int b) {
    clock_++;
    for (int i = 0; i < used; i++) if (blk[i] == b) { age[i] = clock_; hits++; printf("read %2d: HIT\n", b); return; }
    misses++;
    if (used < CACHE) { blk[used] = b; age[used] = clock_; used++; printf("read %2d: MISS (loaded)\n", b); return; }
    int lru = 0;
    for (int i = 1; i < CACHE; i++) if (age[i] < age[lru]) lru = i;       /* least recently used */
    printf("read %2d: MISS (evict block %d)\n", b, blk[lru]);
    blk[lru] = b; age[lru] = clock_;
}
int main(void) {
    int refs[] = {1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5};
    for (unsigned i = 0; i < sizeof refs / sizeof *refs; i++) read_block(refs[i]);
    printf("Hits = %d, misses = %d, hit ratio = %.2f\n", hits, misses, (double)hits / (hits + misses));
    return 0;
}
