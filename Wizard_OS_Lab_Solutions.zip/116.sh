#!/bin/bash
PS3="Choose an option (1-4): "
select opt in "Show disk usage" "Show uptime" "Show logged-in users" "Exit"; do
    case $REPLY in
        1) df -h ;;
        2) uptime ;;
        3) who ;;
        4) echo "Goodbye"; break ;;
        *) echo "Invalid choice" ;;
    esac
done
