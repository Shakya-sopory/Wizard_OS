#include <stdio.h>
#define MAXP 10
#define MAXR 10
int n, m, alloc[MAXP][MAXR], need[MAXP][MAXR], avail[MAXR];
static int is_safe(int *seq) {
    int work[MAXR], fin[MAXP] = {0}, count = 0;
    for (int j = 0; j < m; j++) work[j] = avail[j];
    while (count < n) {
        int progress = 0;
        for (int i = 0; i < n; i++) {
            if (fin[i]) continue;
            int ok = 1;
            for (int j = 0; j < m; j++) if (need[i][j] > work[j]) { ok = 0; break; }
            if (ok) { for (int j = 0; j < m; j++) work[j] += alloc[i][j]; fin[i] = 1; seq[count++] = i; progress = 1; }
        }
        if (!progress) return 0;
    }
    return 1;
}
int main(void) {
    int max[MAXP][MAXR], seq[MAXP];
    printf("Processes and resource types: ");
    if (scanf("%d %d", &n, &m) != 2 || n <= 0 || m <= 0 || n > MAXP || m > MAXR) return 1;
    printf("Allocation:\n"); for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) scanf("%d", &alloc[i][j]);
    printf("Max:\n");        for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) scanf("%d", &max[i][j]);
    printf("Available: ");   for (int j = 0; j < m; j++) scanf("%d", &avail[j]);
    for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) need[i][j] = max[i][j] - alloc[i][j];
    if (!is_safe(seq)) { printf("Initial state is not safe.\n"); return 0; }
    int p, req[MAXR];
    printf("Request: process number and request vector: ");
    scanf("%d", &p); for (int j = 0; j < m; j++) scanf("%d", &req[j]);
    if (p < 0 || p >= n) { printf("Invalid process\n"); return 1; }
    for (int j = 0; j < m; j++) if (req[j] > need[p][j]) { printf("Error: P%d asks for more than its maximum claim.\n", p); return 0; }
    for (int j = 0; j < m; j++) if (req[j] > avail[j]) { printf("P%d must wait: resources not available.\n", p); return 0; }
    for (int j = 0; j < m; j++) { avail[j] -= req[j]; alloc[p][j] += req[j]; need[p][j] -= req[j]; }   /* pretend to allocate */
    if (is_safe(seq)) {
        printf("Request GRANTED. New safe sequence: ");
        for (int i = 0; i < n; i++) printf("P%d%s", seq[i], i < n - 1 ? " -> " : "\n");
    } else {
        for (int j = 0; j < m; j++) { avail[j] += req[j]; alloc[p][j] -= req[j]; need[p][j] += req[j]; }  /* roll back */
        printf("Request DENIED: it would leave the system in an unsafe state. P%d must wait.\n", p);
    }
    return 0;
}
