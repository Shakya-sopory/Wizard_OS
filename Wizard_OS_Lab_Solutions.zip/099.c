/* Compile: gcc -O2 099.c -o iobench ; run:  time ./iobench byte   and   time ./iobench block
   Writes 100 MB. The byte version performs 104,857,600 write() system calls; the block version only 25,600. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#define TOTAL (100L * 1024 * 1024)
int main(int argc, char *argv[]) {
    if (argc != 2) { fprintf(stderr, "Usage: %s byte|block\n", argv[0]); return 1; }
    int fd = open("bench.dat", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) { perror("open"); return 1; }
    if (strcmp(argv[1], "byte") == 0) {
        char c = 'x';
        for (long i = 0; i < TOTAL; i++) write(fd, &c, 1);                 /* one system call per byte */
    } else {
        static char buf[4096];
        memset(buf, 'x', sizeof buf);
        for (long i = 0; i < TOTAL / 4096; i++) write(fd, buf, sizeof buf);  /* one system call per 4 KB */
    }
    close(fd);
    unlink("bench.dat");
    return 0;
}
