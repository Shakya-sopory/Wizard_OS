#include <stdio.h>
#define MAX 10
int n, g[MAX][MAX], color[MAX], parent[MAX];       /* 0 = white, 1 = grey (on stack), 2 = black */
int cyc_start = -1, cyc_end = -1;
int dfs(int u) {
    color[u] = 1;
    for (int v = 0; v < n; v++) {
        if (!g[u][v]) continue;
        if (color[v] == 0) { parent[v] = u; if (dfs(v)) return 1; }
        else if (color[v] == 1) { cyc_start = v; cyc_end = u; return 1; }    /* back edge = cycle */
    }
    color[u] = 2;
    return 0;
}
int main(void) {
    printf("Number of processes: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > MAX) return 1;
    printf("Wait-For Graph adjacency matrix (%dx%d):\n", n, n);
    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) scanf("%d", &g[i][j]);
    for (int i = 0; i < n; i++) parent[i] = -1;
    for (int i = 0; i < n; i++) if (color[i] == 0 && dfs(i)) break;
    if (cyc_start < 0) { printf("No cycle: no deadlock.\n"); return 0; }
    int path[MAX], len = 0;
    for (int v = cyc_end; v != cyc_start; v = parent[v]) path[len++] = v;
    printf("DEADLOCK detected. Cycle: P%d", cyc_start);
    for (int i = len - 1; i >= 0; i--) printf(" -> P%d", path[i]);
    printf(" -> P%d\n", cyc_start);
    return 0;
}
