#include <stdio.h>
#define MAXP 10
#define MAXR 10
int main(void) {
    int n, m;
    printf("Processes and resource types: ");
    if (scanf("%d %d", &n, &m) != 2 || n <= 0 || m <= 0 || n > MAXP || m > MAXR) return 1;
    int alloc[MAXP][MAXR], req[MAXP][MAXR], avail[MAXR], work[MAXR], fin[MAXP];
    printf("Allocation:\n"); for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) scanf("%d", &alloc[i][j]);
    printf("Request:\n");    for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) scanf("%d", &req[i][j]);
    printf("Available: ");   for (int j = 0; j < m; j++) { scanf("%d", &avail[j]); work[j] = avail[j]; }
    for (int i = 0; i < n; i++) {                            /* a process holding nothing cannot be part of a deadlock */
        int holds = 0; for (int j = 0; j < m; j++) holds += alloc[i][j];
        fin[i] = (holds == 0);
    }
    int changed = 1;
    while (changed) {
        changed = 0;
        for (int i = 0; i < n; i++) {
            if (fin[i]) continue;
            int ok = 1;
            for (int j = 0; j < m; j++) if (req[i][j] > work[j]) { ok = 0; break; }   /* current request, not Max */
            if (ok) { for (int j = 0; j < m; j++) work[j] += alloc[i][j]; fin[i] = 1; changed = 1; }
        }
    }
    int dead = 0;
    for (int i = 0; i < n; i++) if (!fin[i]) dead++;
    if (!dead) printf("No deadlock.\n");
    else { printf("DEADLOCK: processes"); for (int i = 0; i < n; i++) if (!fin[i]) printf(" P%d", i); printf(" are deadlocked.\n"); }
    return 0;
}
