/* Writer priority: a turnstile semaphore ('block_readers') is held by the first waiting writer;
   new readers queue up behind it. Writers also count themselves so they get the lock as soon as the active readers leave. */
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
sem_t rw_mutex, r_mutex, w_mutex, block_readers;
int read_count = 0, write_count = 0, shared = 0;
void *reader(void *arg) {
    int id = (int)(long)arg;
    sem_wait(&block_readers);                              /* new readers wait here while a writer is pending */
    sem_wait(&r_mutex);
    if (++read_count == 1) sem_wait(&rw_mutex);
    sem_post(&r_mutex);
    sem_post(&block_readers);
    printf("Reader %d reads %d\n", id, shared);
    usleep(50000);
    sem_wait(&r_mutex);
    if (--read_count == 0) sem_post(&rw_mutex);
    sem_post(&r_mutex);
    return NULL;
}
void *writer(void *arg) {
    int id = (int)(long)arg;
    sem_wait(&w_mutex);
    if (++write_count == 1) sem_wait(&block_readers);      /* first waiting writer closes the door to new readers */
    sem_post(&w_mutex);
    sem_wait(&rw_mutex);
    shared++;
    printf("Writer %d wrote %d\n", id, shared);
    usleep(50000);
    sem_post(&rw_mutex);
    sem_wait(&w_mutex);
    if (--write_count == 0) sem_post(&block_readers);      /* last writer reopens the door */
    sem_post(&w_mutex);
    return NULL;
}
int main(void) {
    sem_init(&rw_mutex, 0, 1); sem_init(&r_mutex, 0, 1); sem_init(&w_mutex, 0, 1); sem_init(&block_readers, 0, 1);
    pthread_t r[5], w[2];
    for (long i = 0; i < 5; i++) {
        pthread_create(&r[i], NULL, reader, (void *)(i + 1)); usleep(10000);
        if (i == 1) pthread_create(&w[0], NULL, writer, (void *)1L);
        if (i == 3) pthread_create(&w[1], NULL, writer, (void *)2L);
    }
    for (int i = 0; i < 5; i++) pthread_join(r[i], NULL);
    pthread_join(w[0], NULL); pthread_join(w[1], NULL);
    return 0;
}
