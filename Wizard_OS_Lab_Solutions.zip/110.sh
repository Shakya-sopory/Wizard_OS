#!/bin/bash
# usage: ./110.sh <process-name>   sends SIGTERM (graceful) to all matching processes
[ $# -eq 1 ] || { echo "Usage: $0 <process-name>" >&2; exit 1; }
pids=$(pgrep -x "$1")
if [ -z "$pids" ]; then echo "No process named '$1' is running"; exit 1; fi
for pid in $pids; do
    echo "Sending SIGTERM to $1 (PID $pid)"
    kill -15 "$pid"
done
sleep 2
for pid in $pids; do kill -0 "$pid" 2>/dev/null && echo "PID $pid still running (use kill -9 as a last resort)"; done
exit 0
