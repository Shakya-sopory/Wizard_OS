#include <stdio.h>
#define MAXP 10
#define MAXR 10
int main(void) {
    int n, m;
    printf("Processes and resource types: ");
    if (scanf("%d %d", &n, &m) != 2 || n <= 0 || m <= 0 || n > MAXP || m > MAXR) return 1;
    int alloc[MAXP][MAXR], max[MAXP][MAXR], need[MAXP][MAXR], avail[MAXR], work[MAXR], fin[MAXP] = {0}, seq[MAXP];
    printf("Allocation matrix:\n"); for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) scanf("%d", &alloc[i][j]);
    printf("Max matrix:\n");        for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) scanf("%d", &max[i][j]);
    printf("Available vector: ");   for (int j = 0; j < m; j++) { scanf("%d", &avail[j]); work[j] = avail[j]; }
    for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) need[i][j] = max[i][j] - alloc[i][j];
    int count = 0;
    while (count < n) {
        int progress = 0;
        for (int i = 0; i < n; i++) {
            if (fin[i]) continue;
            int ok = 1;
            for (int j = 0; j < m; j++) if (need[i][j] > work[j]) { ok = 0; break; }
            if (ok) {
                for (int j = 0; j < m; j++) work[j] += alloc[i][j];     /* process finishes, releases resources */
                fin[i] = 1; seq[count++] = i; progress = 1;
            }
        }
        if (!progress) break;
    }
    if (count == n) { printf("SAFE state. Safe sequence: "); for (int i = 0; i < n; i++) printf("P%d%s", seq[i], i < n - 1 ? " -> " : "\n"); }
    else printf("UNSAFE state (deadlock possible): only %d of %d processes can finish.\n", count, n);
    return 0;
}
