#include <stdio.h>
#define TLB 4
int main(void) {
    int page_table[16] = {5, 2, 7, 0, 3, 6, 1, 4, 9, 8, 11, 10, 13, 12, 15, 14};
    int tlb_page[TLB], tlb_frame[TLB], tlb_age[TLB], used = 0;       /* LRU replacement in the TLB */
    unsigned page_size = 256;
    int n;
    double tlb_time = 10, mem_time = 100;                            /* ns */
    printf("Number of accesses: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 1000) return 1;
    int hits = 0;
    printf("Logical addresses (page size %u): ", page_size);
    for (int i = 0; i < n; i++) {
        unsigned addr; scanf("%u", &addr);
        unsigned page = addr / page_size, off = addr % page_size;
        if (page > 15) { printf("%u: invalid page\n", addr); continue; }
        int pos = -1;
        for (int j = 0; j < used; j++) if (tlb_page[j] == (int)page) { pos = j; break; }
        if (pos >= 0) { hits++; tlb_age[pos] = i; printf("%5u: TLB hit,  physical %u\n", addr, tlb_frame[pos] * page_size + off); }
        else {
            int frame = page_table[page];
            if (used < TLB) pos = used++;
            else { pos = 0; for (int j = 1; j < TLB; j++) if (tlb_age[j] < tlb_age[pos]) pos = j; }
            tlb_page[pos] = page; tlb_frame[pos] = frame; tlb_age[pos] = i;
            printf("%5u: TLB miss, physical %u\n", addr, frame * page_size + off);
        }
    }
    double h = (double)hits / n;
    double eat = h * (tlb_time + mem_time) + (1 - h) * (tlb_time + 2 * mem_time);
    printf("Hits = %d / %d, hit ratio = %.2f\n", hits, n, h);
    printf("EAT = h*(t+m) + (1-h)*(t+2m) = %.1f ns (t = %.0f ns, m = %.0f ns)\n", eat, tlb_time, mem_time);
    return 0;
}
