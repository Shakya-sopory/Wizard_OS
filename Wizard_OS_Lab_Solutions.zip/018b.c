/* Reader (Program B). Compile: gcc 018b.c -o reader -lrt */
#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#define NAME "/wizard_shm"
#define SIZE 4096
int main(void) {
    int fd = shm_open(NAME, O_RDONLY, 0666);
    if (fd < 0) { perror("shm_open (run the writer first)"); return 1; }
    char *p = mmap(NULL, SIZE, PROT_READ, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) { perror("mmap"); return 1; }
    printf("Reader got: %s", p);
    munmap(p, SIZE);
    close(fd);
    shm_unlink(NAME);                    /* remove the segment */
    return 0;
}
