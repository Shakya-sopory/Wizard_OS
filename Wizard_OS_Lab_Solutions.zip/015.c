#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>
void *work(void *a) {
    sleep(1);
    printf("Detached thread done\n");
    return NULL;
}
int main(void) {
    pthread_t t;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&t, &attr, work, NULL);
    pthread_attr_destroy(&attr);
    int rc = pthread_join(t, NULL);          /* must fail: the thread is detached */
    if (rc != 0) printf("pthread_join failed as expected: %s (error %d, EINVAL=%d)\n", strerror(rc), rc, EINVAL);
    else printf("join succeeded (unexpected)\n");
    sleep(2);                                /* let the detached thread finish */
    return 0;
}
