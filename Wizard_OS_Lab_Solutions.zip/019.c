#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(void) {
    int tickets[3] = {10, 20, 70}, total = 100, wins[3] = {0, 0, 0};
    const int BURSTS = 1000;
    srand((unsigned)time(NULL));
    for (int b = 0; b < BURSTS; b++) {
        int draw = rand() % total, acc = 0;         /* winning ticket */
        for (int i = 0; i < 3; i++) {
            acc += tickets[i];
            if (draw < acc) { wins[i]++; break; }
        }
    }
    printf("Process  Tickets  Expected%%  Bursts  Actual%%\n");
    for (int i = 0; i < 3; i++)
        printf("P%d       %3d      %5.1f     %4d    %5.1f\n", i + 1, tickets[i],
               100.0 * tickets[i] / total, wins[i], 100.0 * wins[i] / BURSTS);
    printf("Actual shares approach the ticket ratio 10:20:70 as the number of bursts grows.\n");
    return 0;
}
