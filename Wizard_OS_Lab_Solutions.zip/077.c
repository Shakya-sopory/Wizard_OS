#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#define CARS 12
sem_t bridge, turn, dir_mutex[2];
int count[2] = {0, 0};
const char *name[2] = {"North", "South"};
void *car(void *arg) {
    long id = (long)arg;
    int d = id % 2;                                         /* 0 = from North, 1 = from South (random-ish arrival) */
    usleep((rand() % 300) * 1000);
    sem_wait(&turn);                                        /* turnstile prevents starvation of the other side */
    sem_wait(&dir_mutex[d]);
    if (++count[d] == 1) sem_wait(&bridge);                 /* first car of this direction claims the bridge */
    sem_post(&dir_mutex[d]);
    sem_post(&turn);
    printf("Car %ld from %s is crossing (%d on the bridge in this direction)\n", id, name[d], count[d]);
    usleep(100000);
    sem_wait(&dir_mutex[d]);
    if (--count[d] == 0) sem_post(&bridge);                 /* last car frees the bridge */
    sem_post(&dir_mutex[d]);
    printf("Car %ld from %s has crossed\n", id, name[d]);
    return NULL;
}
int main(void) {
    srand(5);
    sem_init(&bridge, 0, 1); sem_init(&turn, 0, 1); sem_init(&dir_mutex[0], 0, 1); sem_init(&dir_mutex[1], 0, 1);
    pthread_t t[CARS];
    for (long i = 0; i < CARS; i++) pthread_create(&t[i], NULL, car, (void *)i);
    for (int i = 0; i < CARS; i++) pthread_join(t[i], NULL);
    return 0;
}
