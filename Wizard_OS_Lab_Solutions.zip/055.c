/* Livelock: two threads politely step aside forever. Burns 100% of two CPUs. Stop with Ctrl-C. */
#include <stdio.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
atomic_int wants[2];
static void *person(void *arg) {
    int me = (int)(long)arg, other = 1 - me;
    unsigned long steps = 0;
    while (1) {
        atomic_store(&wants[me], 1);
        if (atomic_load(&wants[other])) {          /* other also wants the same spot: politely give way */
            atomic_store(&wants[me], 0);
            sched_yield();
            if (++steps % 50000000 == 0) printf("Person %d: still stepping aside (%lu times), no progress\n", me, steps);
            continue;                              /* both do the same in lockstep, so nobody ever passes */
        }
        printf("Person %d passed\n", me);          /* rarely reached, depends on timing */
        break;
    }
    return NULL;
}
int main(void) {
    pthread_t a, b;
    pthread_create(&a, NULL, person, (void *)0L); pthread_create(&b, NULL, person, (void *)1L);
    pthread_join(a, NULL); pthread_join(b, NULL);
    return 0;
}
