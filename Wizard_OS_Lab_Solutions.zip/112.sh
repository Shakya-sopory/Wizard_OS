#!/bin/bash
# usage: ./112.sh [directory]
dir=${1:-.}
[ -d "$dir" ] || { echo "Not a directory: $dir" >&2; exit 1; }
find "$dir" -type f -name "*.sh" -exec chmod +x {} + -print
