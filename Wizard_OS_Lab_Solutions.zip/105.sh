#!/bin/bash
# usage: ./105.sh <directory-to-back-up>
[ $# -eq 1 ] && [ -d "$1" ] || { echo "Usage: $0 <directory>" >&2; exit 1; }
src=$(realpath "$1")
dest="$(basename "$src")_backup_$(date +%F).tar.gz"
tar -czvf "$dest" -C "$(dirname "$src")" "$(basename "$src")" && echo "Backup created: $dest ($(du -h "$dest" | cut -f1))"
