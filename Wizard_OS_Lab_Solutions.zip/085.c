#include <stdio.h>
#include <stdlib.h>
static void sort(int *a, int n) { for (int i = 0; i < n - 1; i++) for (int j = 0; j < n - i - 1; j++) if (a[j] > a[j + 1]) { int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t; } }
int main(void) {
    int n, head, dir;
    printf("Number of requests: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 100) return 1;
    int req[100];
    printf("Requests: "); for (int i = 0; i < n; i++) scanf("%d", &req[i]);
    printf("Head position and direction (0 = down, 1 = up): "); scanf("%d %d", &head, &dir);
    sort(req, n);
    /* LOOK: reverse at the last request in the current direction */
    int total = 0, cur = head;
    printf("LOOK    : %d", cur);
    if (dir == 1) {
        for (int i = 0; i < n; i++) if (req[i] >= head) { total += req[i] - cur; cur = req[i]; printf(" -> %d", cur); }
        for (int i = n - 1; i >= 0; i--) if (req[i] < head) { total += cur - req[i]; cur = req[i]; printf(" -> %d", cur); }
    } else {
        for (int i = n - 1; i >= 0; i--) if (req[i] <= head) { total += cur - req[i]; cur = req[i]; printf(" -> %d", cur); }
        for (int i = 0; i < n; i++) if (req[i] > head) { total += req[i] - cur; cur = req[i]; printf(" -> %d", cur); }
    }
    printf("\n          total = %d\n", total);
    /* C-LOOK: after the last request, jump to the request at the opposite end, then continue in the same direction */
    int t2 = 0, jump = 0; cur = head;
    printf("C-LOOK  : %d", cur);
    if (dir == 1) {
        for (int i = 0; i < n; i++) if (req[i] >= head) { t2 += req[i] - cur; cur = req[i]; printf(" -> %d", cur); }
        int first = -1; for (int i = 0; i < n; i++) if (req[i] < head) { first = req[i]; break; }
        if (first >= 0) { jump = cur - first; cur = first; printf(" => %d (jump)", cur);
            for (int i = 0; i < n; i++) if (req[i] < head && req[i] != first) { t2 += req[i] - cur; cur = req[i]; printf(" -> %d", cur); } }
    } else {
        for (int i = n - 1; i >= 0; i--) if (req[i] <= head) { t2 += cur - req[i]; cur = req[i]; printf(" -> %d", cur); }
        int last = -1; for (int i = n - 1; i >= 0; i--) if (req[i] > head) { last = req[i]; break; }
        if (last >= 0) { jump = last - cur; cur = last; printf(" => %d (jump)", cur);
            for (int i = n - 1; i >= 0; i--) if (req[i] > head && req[i] != last) { t2 += cur - req[i]; cur = req[i]; printf(" -> %d", cur); } }
    }
    printf("\n          movement without jump = %d, with the jump of %d = %d\n", t2, jump, t2 + jump);
    return 0;
}
