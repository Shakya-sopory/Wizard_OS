#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#define N 5
typedef struct { pthread_mutex_t m; pthread_cond_t cv; int count, total, generation; } Barrier;
Barrier bar = {PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER, 0, N, 0};
void barrier_wait(Barrier *b) {
    pthread_mutex_lock(&b->m);
    int gen = b->generation;
    if (++b->count == b->total) {                     /* last thread arrives: open the barrier */
        b->generation++; b->count = 0;
        pthread_cond_broadcast(&b->cv);
    } else {
        while (gen == b->generation) pthread_cond_wait(&b->cv, &b->m);
    }
    pthread_mutex_unlock(&b->m);
}
void *worker(void *arg) {
    int id = (int)(long)arg;
    usleep(100000 * id);                              /* threads arrive at different times */
    printf("Thread %d reached the barrier\n", id);
    barrier_wait(&bar);
    printf("Thread %d passed the barrier\n", id);
    return NULL;
}
int main(void) {
    pthread_t t[N];
    for (long i = 1; i <= N; i++) pthread_create(&t[i - 1], NULL, worker, (void *)i);
    for (int i = 0; i < N; i++) pthread_join(t[i], NULL);
    return 0;
}
