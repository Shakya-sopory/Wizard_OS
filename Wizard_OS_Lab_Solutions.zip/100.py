#!/usr/bin/env python3
"""Plot the disk-head path for FCFS and SSTF. X axis = step, Y axis = cylinder."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def fcfs(head, reqs):
    return [head] + list(reqs)

def sstf(head, reqs):
    path, pending, cur = [head], list(reqs), head
    while pending:
        nxt = min(pending, key=lambda r: abs(r - cur))
        pending.remove(nxt)
        path.append(nxt)
        cur = nxt
    return path

def movement(path):
    return sum(abs(a - b) for a, b in zip(path, path[1:]))

head, requests = 53, [98, 183, 37, 122, 14, 124, 65, 67]
paths = {"FCFS": fcfs(head, requests), "SSTF": sstf(head, requests)}

fig, axes = plt.subplots(1, 2, figsize=(11, 5), sharey=True)
for ax, (name, p) in zip(axes, paths.items()):
    ax.plot(range(len(p)), p, marker="o")
    for i, c in enumerate(p):
        ax.annotate(str(c), (i, c), textcoords="offset points", xytext=(4, 4), fontsize=8)
    ax.set_title(f"{name}: total movement = {movement(p)} cylinders")
    ax.set_xlabel("Step (time)")
    ax.grid(True, alpha=0.3)
axes[0].set_ylabel("Cylinder")
plt.tight_layout()
plt.savefig("disk_head_paths.png", dpi=120)
print({k: movement(v) for k, v in paths.items()}, "-> saved disk_head_paths.png")
