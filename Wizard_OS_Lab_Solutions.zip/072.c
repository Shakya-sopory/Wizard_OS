#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#define THREADS 8
#define OPS 200000
int shared = 0;
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
pthread_rwlock_t rw = PTHREAD_RWLOCK_INITIALIZER;
int use_rw;
static void spin_work(void) { volatile int x = 0; for (int i = 0; i < 200; i++) x += i; }   /* work done inside the critical section */
void *worker(void *arg) {
    unsigned seed = (unsigned)(long)arg * 17;
    for (int i = 0; i < OPS; i++) {
        int is_write = rand_r(&seed) % 100 < 5;               /* 5% writes, 95% reads */
        if (use_rw) { if (is_write) pthread_rwlock_wrlock(&rw); else pthread_rwlock_rdlock(&rw); }
        else pthread_mutex_lock(&mtx);
        if (is_write) shared++; else { volatile int v = shared; (void)v; spin_work(); }
        if (use_rw) pthread_rwlock_unlock(&rw); else pthread_mutex_unlock(&mtx);
    }
    return NULL;
}
static double run(int rw_mode) {
    use_rw = rw_mode;
    pthread_t t[THREADS]; struct timespec s, e;
    clock_gettime(CLOCK_MONOTONIC, &s);
    for (long i = 0; i < THREADS; i++) pthread_create(&t[i], NULL, worker, (void *)(i + 1));
    for (int i = 0; i < THREADS; i++) pthread_join(t[i], NULL);
    clock_gettime(CLOCK_MONOTONIC, &e);
    return (e.tv_sec - s.tv_sec) + (e.tv_nsec - s.tv_nsec) / 1e9;
}
int main(void) {
    double tm = run(0), tr = run(1);
    printf("mutex   : %.3f s\nrwlock  : %.3f s\nspeed-up of rwlock for a 95%% read workload: %.2fx (needs several cores)\n", tm, tr, tm / tr);
    return 0;
}
