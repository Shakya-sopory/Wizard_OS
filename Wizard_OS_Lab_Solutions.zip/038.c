/* Kernel module is not possible to run in this sandbox; this is the user-space alternative based on /proc.
   Counts minor and major page faults of a PID (fields 10 and 12 of /proc/PID/stat) before and after a workload.
   For the eBPF option:  sudo bpftrace -e 'software:page-faults:1 /pid == PID/ { @[comm] = count(); }'
   or  perf stat -e minor-faults,major-faults -p PID . A real kernel-module version would use a kprobe on handle_mm_fault. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static void faults(int pid, long *minor, long *major) {
    char path[64], buf[1024];
    snprintf(path, sizeof path, "/proc/%d/stat", pid);
    FILE *f = fopen(path, "r");
    if (!f) { perror("fopen"); exit(1); }
    fgets(buf, sizeof buf, f); fclose(f);
    char *p = strrchr(buf, ')') + 2;                    /* skip "pid (comm) " */
    long v[40]; char state;
    sscanf(p, "%c %ld %ld %ld %ld %ld %ld %ld %ld %ld", &state, &v[0], &v[1], &v[2], &v[3], &v[4], &v[5], &v[6], &v[7], &v[8]);
    /* after state: ppid pgrp session tty tpgid flags minflt cminflt majflt */
    *minor = v[6]; *major = v[8];
}
int main(int argc, char *argv[]) {
    int pid = argc > 1 ? atoi(argv[1]) : getpid();
    long m0, M0, m1, M1;
    faults(pid, &m0, &M0);
    if (pid == getpid()) {                                  /* generate some page faults ourselves */
        size_t sz = 64 * 1024 * 1024; char *p = malloc(sz);
        for (size_t i = 0; i < sz; i += 4096) p[i] = 1;
    } else sleep(5);
    faults(pid, &m1, &M1);
    printf("PID %d: minor faults +%ld, major faults +%ld\n", pid, m1 - m0, M1 - M0);
    return 0;
}
