#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main(void) {
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    if (pid == 0) {
        char *args[] = {"ls", "-l", NULL};
        execvp(args[0], args);
        perror("execvp");          /* reached only if exec fails */
        exit(1);
    }
    int status;
    waitpid(pid, &status, 0);
    printf("Parent: child finished (exit status %d)\n", WEXITSTATUS(status));
    return 0;
}
