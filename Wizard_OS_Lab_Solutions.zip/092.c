#include <stdio.h>
#define BLOCK_SIZE 4096
#define DIRECT 10
typedef struct {
    unsigned int mode, uid, size;
    unsigned int direct[DIRECT];            /* 10 direct block pointers */
    unsigned int single_indirect;           /* 1 single-indirect pointer */
} Inode;
unsigned long long max_file_size(unsigned block_size, unsigned ptr_size) {
    unsigned long long ptrs = block_size / ptr_size;                      /* pointers per indirect block */
    return (DIRECT + ptrs) * (unsigned long long)block_size;
}
int main(void) {
    unsigned ptr = sizeof(unsigned int);
    unsigned long long m = max_file_size(BLOCK_SIZE, ptr);
    printf("Pointers per block = %u\n", BLOCK_SIZE / ptr);
    printf("Direct: %d x 4 KB = %d KB, single indirect: %u x 4 KB = %u KB\n", DIRECT, DIRECT * 4, BLOCK_SIZE / ptr, BLOCK_SIZE / ptr * 4);
    printf("Maximum file size = %llu bytes = %.2f MB\n", m, m / (1024.0 * 1024.0));
    printf("sizeof(Inode) = %zu bytes\n", sizeof(Inode));
    return 0;
}
