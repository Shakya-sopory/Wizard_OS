/* Program A (writer). Compile: gcc 018.c -o writer -lrt     Program B is lab/018b.c  */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#define NAME "/wizard_shm"
#define SIZE 4096
int main(void) {
    int fd = shm_open(NAME, O_CREAT | O_RDWR, 0666);
    if (fd < 0) { perror("shm_open"); return 1; }
    if (ftruncate(fd, SIZE) < 0) { perror("ftruncate"); return 1; }
    char *p = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) { perror("mmap"); return 1; }
    printf("Enter a message: ");
    fflush(stdout);
    if (!fgets(p, SIZE, stdin)) p[0] = '\0';
    printf("Written to shared memory %s. Now run the reader (Program B).\n", NAME);
    munmap(p, SIZE);
    close(fd);
    return 0;
}
