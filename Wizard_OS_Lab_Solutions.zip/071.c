#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
/* Agent puts two ingredients; pushers decide which smoker can make a cigarette (avoids the deadlock of the naive solution). */
sem_t agent, tobacco, paper, match;                 /* ingredients on the table */
sem_t smoker_sem[3], mutex;                         /* smoker 0 has tobacco, 1 has paper, 2 has matches */
int is_tobacco = 0, is_paper = 0, is_match = 0;
#define ROUNDS 9
void *agent_thread(void *a) {
    for (int r = 0; r < ROUNDS; r++) {
        sem_wait(&agent);
        int k = rand() % 3;
        if (k == 0)      { printf("Agent puts paper and matches\n");   sem_post(&paper);   sem_post(&match); }
        else if (k == 1) { printf("Agent puts tobacco and matches\n"); sem_post(&tobacco); sem_post(&match); }
        else             { printf("Agent puts tobacco and paper\n");   sem_post(&tobacco); sem_post(&paper); }
    }
    return NULL;
}
void *pusher_tobacco(void *a) {
    for (int i = 0; i < ROUNDS; i++) { sem_wait(&tobacco); sem_wait(&mutex);
        if (is_paper) { is_paper = 0; sem_post(&smoker_sem[2]); }
        else if (is_match) { is_match = 0; sem_post(&smoker_sem[1]); }
        else is_tobacco = 1;
        sem_post(&mutex); }
    return NULL;
}
void *pusher_paper(void *a) {
    for (int i = 0; i < ROUNDS; i++) { sem_wait(&paper); sem_wait(&mutex);
        if (is_tobacco) { is_tobacco = 0; sem_post(&smoker_sem[2]); }
        else if (is_match) { is_match = 0; sem_post(&smoker_sem[0]); }
        else is_paper = 1;
        sem_post(&mutex); }
    return NULL;
}
void *pusher_match(void *a) {
    for (int i = 0; i < ROUNDS; i++) { sem_wait(&match); sem_wait(&mutex);
        if (is_tobacco) { is_tobacco = 0; sem_post(&smoker_sem[1]); }
        else if (is_paper) { is_paper = 0; sem_post(&smoker_sem[0]); }
        else is_match = 1;
        sem_post(&mutex); }
    return NULL;
}
const char *names[3] = {"tobacco", "paper", "matches"};
void *smoker(void *arg) {
    int id = (int)(long)arg;
    while (1) {
        sem_wait(&smoker_sem[id]);
        printf("   Smoker with %s makes and smokes a cigarette\n", names[id]);
        usleep(20000);
        sem_post(&agent);
    }
    return NULL;
}
int main(void) {
    srand(2);
    sem_init(&agent, 0, 1); sem_init(&tobacco, 0, 0); sem_init(&paper, 0, 0); sem_init(&match, 0, 0); sem_init(&mutex, 0, 1);
    for (int i = 0; i < 3; i++) sem_init(&smoker_sem[i], 0, 0);
    pthread_t t[7];
    pthread_create(&t[0], NULL, agent_thread, NULL);
    pthread_create(&t[1], NULL, pusher_tobacco, NULL); pthread_create(&t[2], NULL, pusher_paper, NULL); pthread_create(&t[3], NULL, pusher_match, NULL);
    for (long i = 0; i < 3; i++) pthread_create(&t[4 + i], NULL, smoker, (void *)i);
    pthread_join(t[0], NULL);                    /* agent finished; pushers/smokers loop forever, so exit the process */
    usleep(300000);
    printf("Done (%d rounds).\n", ROUNDS);
    exit(0);
}
