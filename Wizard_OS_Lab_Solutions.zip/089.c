#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
int main(int argc, char *argv[]) {
    const char *path = argc > 1 ? argv[1] : ".";
    DIR *d = opendir(path);
    if (!d) { perror("opendir"); return 1; }
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
        char full[4096]; struct stat st;
        snprintf(full, sizeof full, "%s/%s", path, e->d_name);
        printf("%s%s\n", e->d_name, (stat(full, &st) == 0 && S_ISDIR(st.st_mode)) ? "/" : "");
    }
    closedir(d);
    return 0;
}
