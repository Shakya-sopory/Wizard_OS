#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#define MOLECULES 4
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
sem_t hQueue, oQueue;
pthread_barrier_t bar;
int h_count = 0, o_count = 0;
void bind_atoms(void) { printf("bond(): H2O molecule formed\n"); }
void *hydrogen(void *a) {
    pthread_mutex_lock(&m);
    if (h_count >= 1 && o_count >= 1) {                   /* this H completes a group (1 H + 1 O waiting) */
        h_count--; o_count--;
        sem_post(&hQueue); sem_post(&oQueue);             /* release the waiting H and O */
        pthread_mutex_unlock(&m);
    } else {
        h_count++;                                        /* not enough partners yet: wait */
        pthread_mutex_unlock(&m);
        sem_wait(&hQueue);
    }
    pthread_barrier_wait(&bar);                           /* the three atoms of a molecule meet here */
    return NULL;
}
void *oxygen(void *a) {
    pthread_mutex_lock(&m);
    if (h_count >= 2) {                                   /* two H already waiting */
        h_count -= 2;
        sem_post(&hQueue); sem_post(&hQueue);
        pthread_mutex_unlock(&m);
    } else {
        o_count++;
        pthread_mutex_unlock(&m);
        sem_wait(&oQueue);
    }
    pthread_barrier_wait(&bar);
    bind_atoms();                                         /* exactly one O per molecule calls bond() */
    return NULL;
}
int main(void) {
    sem_init(&hQueue, 0, 0); sem_init(&oQueue, 0, 0);
    pthread_barrier_init(&bar, NULL, 3);
    pthread_t t[MOLECULES * 3];
    int n = 0;
    for (int i = 0; i < MOLECULES; i++) {
        pthread_create(&t[n++], NULL, hydrogen, NULL); usleep(1000);
        pthread_create(&t[n++], NULL, oxygen, NULL);   usleep(1000);
        pthread_create(&t[n++], NULL, hydrogen, NULL); usleep(1000);
    }
    for (int i = 0; i < n; i++) pthread_join(t[i], NULL);
    printf("Formed %d molecules.\n", MOLECULES);
    return 0;
}
