/* WARNING: resource exhaustion test. Run only in a VM/container with a low limit, e.g.:  (ulimit -n 4096; ./057)
   Each iteration opens a new file descriptor and takes an flock() on it. Nothing is ever released.
   Watch:  dmesg | tail ;  ls /proc/<pid>/fd | wc -l .
   Linux does not detect or prevent this; it fails the call with EMFILE (per-process descriptor limit) or ENFILE (system limit),
   and under real memory exhaustion the OOM killer ends a process (the "ostrich" approach: no deadlock handling). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/file.h>
int main(void) {
    long count = 0;
    char name[64];
    while (1) {
        snprintf(name, sizeof name, "/tmp/lockfile_%ld", count % 100000);
        int fd = open(name, O_CREAT | O_RDWR, 0600);
        if (fd < 0) { printf("open failed after %ld locks: %s\n", count, strerror(errno)); break; }
        flock(fd, LOCK_SH);                      /* shared lock that is never released */
        count++;
    }
    for (int i = 0; i < 100000; i++) { snprintf(name, sizeof name, "/tmp/lockfile_%d", i); unlink(name); }
    return 0;
}
