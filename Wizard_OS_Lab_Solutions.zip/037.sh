#!/bin/bash
# Write the hello world program, trace it with strace and show the heap-related calls.
cat > /tmp/hello.c <<'EOF'
#include <stdio.h>
int main(void) { printf("Hello, World\n"); return 0; }
EOF
gcc /tmp/hello.c -o /tmp/hello || exit 1
strace -o /tmp/hello.trace /tmp/hello
echo "---- brk() and mmap() calls (heap / memory initialisation) ----"
grep -E '^(brk|mmap|munmap)' /tmp/hello.trace
echo "---- write call that prints the text ----"
grep '^write' /tmp/hello.trace
# Explanation: the first brk(NULL) returns the current end of the heap; the dynamic loader and libc use
# mmap() to map libc.so and anonymous memory; the later brk(addr) call extends the heap used by stdio's malloc.
