#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#define M 4
#define K 3
#define N 5
int A[M][K], B[K][N], C[M][N];
void *row(void *arg) {
    int i = (int)(long)arg;
    for (int j = 0; j < N; j++) {
        C[i][j] = 0;
        for (int k = 0; k < K; k++) C[i][j] += A[i][k] * B[k][j];
    }
    return NULL;
}
int main(void) {
    for (int i = 0; i < M; i++) for (int k = 0; k < K; k++) A[i][k] = i + k + 1;
    for (int k = 0; k < K; k++) for (int j = 0; j < N; j++) B[k][j] = k * j + 1;
    pthread_t th[M];
    for (int i = 0; i < M; i++) pthread_create(&th[i], NULL, row, (void *)(long)i);   /* one thread per row */
    for (int i = 0; i < M; i++) pthread_join(th[i], NULL);
    printf("Result C = A x B (%dx%d):\n", M, N);
    for (int i = 0; i < M; i++) { for (int j = 0; j < N; j++) printf("%5d", C[i][j]); printf("\n"); }
    return 0;
}
