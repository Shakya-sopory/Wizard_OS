#include <iostream>
#include <mutex>
#include <thread>
#include <vector>
using namespace std;
class BankMonitor {                                   // monitor: private data + all access through locked methods
    int balance_;
    mutable mutex m_;
public:
    explicit BankMonitor(int b) : balance_(b) {}
    void deposit(int x) { lock_guard<mutex> g(m_); balance_ += x; }                 // lock on entry, unlock on exit
    bool withdraw(int x) { lock_guard<mutex> g(m_); if (balance_ < x) return false; balance_ -= x; return true; }
    int balance() const { lock_guard<mutex> g(m_); return balance_; }
};
int main() {
    BankMonitor acct(100000);
    vector<thread> ts;
    for (int i = 0; i < 4; i++) ts.emplace_back([&] { for (int k = 0; k < 10000; k++) acct.deposit(1); });
    for (int i = 0; i < 4; i++) ts.emplace_back([&] { for (int k = 0; k < 10000; k++) acct.withdraw(1); });
    for (auto &t : ts) t.join();
    cout << "Final balance = " << acct.balance() << " (expected 100000)\n";
    return 0;
}
