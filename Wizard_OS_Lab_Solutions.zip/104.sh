#!/bin/bash
# Warn when available memory is below 10% of total. Needs permission to write the log (run as root or change LOG).
LOG=${LOG:-/var/log/memalert.log}
total=$(free -m | awk '/^Mem:/ {print $2}')
avail=$(free -m | awk '/^Mem:/ {print $7}')            # 'available' column
pct=$(( avail * 100 / total ))
echo "Available memory: ${avail} MB of ${total} MB (${pct}%)"
if [ "$pct" -lt 10 ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') WARNING: available memory low: ${pct}% (${avail} MB of ${total} MB)" >> "$LOG" \
        || echo "Cannot write to $LOG (run as root)" >&2
fi
