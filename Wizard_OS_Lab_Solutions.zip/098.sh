#!/bin/bash
# Usage: sudo ./098.sh [device]   (default: the device holding /)
DEV=${1:-$(findmnt -n -o SOURCE /)}
echo "Device: $DEV"
if ! command -v dumpe2fs >/dev/null; then echo "dumpe2fs not installed (package e2fsprogs)"; exit 1; fi
sudo dumpe2fs -h "$DEV" 2>/dev/null | head -n 50 > superblock.txt
cat superblock.txt
echo "---------------- summary to document ----------------"
grep -E "^(Block size|Inode count|Free blocks|Block count|Free inodes|Inodes per group|Blocks per group|Filesystem volume name):" superblock.txt
# Note: only ext2/3/4 file systems work; on an XFS or btrfs system use xfs_info / btrfs filesystem show.
