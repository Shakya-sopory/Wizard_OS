#include <stdio.h>
int main(void) {
    int nf, n;
    printf("Number of frames: ");
    if (scanf("%d", &nf) != 1 || nf <= 0 || nf > 50) return 1;
    printf("Length of reference string: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 200) return 1;
    int ref[200], frame[50], last[50], faults = 0, used = 0;
    printf("Reference string: ");
    for (int i = 0; i < n; i++) scanf("%d", &ref[i]);
    for (int i = 0; i < n; i++) {
        int pos = -1;
        for (int j = 0; j < used; j++) if (frame[j] == ref[i]) { pos = j; break; }
        if (pos >= 0) { last[pos] = i; printf("%3d : hit\n", ref[i]); continue; }    /* update age */
        faults++;
        if (used < nf) { frame[used] = ref[i]; last[used] = i; used++; }
        else {
            int lru = 0;                                    /* page with the smallest last-use time */
            for (int j = 1; j < nf; j++) if (last[j] < last[lru]) lru = j;
            frame[lru] = ref[i]; last[lru] = i;
        }
        printf("%3d : FAULT  frames:", ref[i]);
        for (int j = 0; j < used; j++) printf(" %d", frame[j]);
        printf("\n");
    }
    printf("Total page faults (LRU) = %d\n", faults);
    return 0;
}
