#include <stdio.h>
#include <stdint.h>
#define BLOCKS 64
uint8_t bitmap[BLOCKS / 8];                          /* bit = 1: block is free, 0: allocated */
static int  is_free(int b)  { return (bitmap[b / 8] >> (b % 8)) & 1; }
void allocate_block(int b)  { bitmap[b / 8] &= ~(1u << (b % 8)); }       /* set bit to 0 */
void free_block(int b)      { bitmap[b / 8] |=  (1u << (b % 8)); }       /* set bit to 1 */
int find_contiguous(int k) {
    int run = 0;
    for (int b = 0; b < BLOCKS; b++) {
        run = is_free(b) ? run + 1 : 0;
        if (run == k) return b - k + 1;
    }
    return -1;
}
static void show(void) { for (int b = 0; b < BLOCKS; b++) { putchar(is_free(b) ? '1' : '0'); if (b % 8 == 7) putchar(' '); } putchar('\n'); }
int main(void) {
    for (int i = 0; i < BLOCKS / 8; i++) bitmap[i] = 0xFF;                /* all free */
    int used[] = {0, 1, 2, 5, 9, 10, 12, 13, 14, 20};
    for (unsigned i = 0; i < sizeof used / sizeof *used; i++) allocate_block(used[i]);
    printf("Bit vector (1 = free):\n"); show();
    int s = find_contiguous(3);
    printf("First run of 3 contiguous free blocks starts at block %d\n", s);
    for (int i = 0; i < 3; i++) allocate_block(s + i);
    show();
    free_block(1);
    printf("After freeing block 1:\n"); show();
    return 0;
}
