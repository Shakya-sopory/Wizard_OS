#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
static void walk(const char *path, int depth) {
    DIR *d = opendir(path);
    if (!d) { perror(path); return; }
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
        char full[4096]; struct stat st;
        snprintf(full, sizeof full, "%s/%s", path, e->d_name);
        if (lstat(full, &st) < 0) continue;                     /* lstat: do not follow symlinks (avoids loops) */
        for (int i = 0; i < depth; i++) printf("|   ");
        printf("|-- %s%s\n", e->d_name, S_ISDIR(st.st_mode) ? "/" : "");
        if (S_ISDIR(st.st_mode)) walk(full, depth + 1);
    }
    closedir(d);
}
int main(int argc, char *argv[]) {
    const char *root = argc > 1 ? argv[1] : ".";
    printf("%s/\n", root);
    walk(root, 0);
    return 0;
}
