/* BUG ON PURPOSE (lost wake-up): the signal is sent before the waiter waits, and nothing remembers it.
   The program hangs; stop it with Ctrl-C. The fix is a predicate (flag) that the waiter checks under the mutex. */
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cv = PTHREAD_COND_INITIALIZER;
void *waiter(void *a) {
    sleep(1);                                  /* waiter is late */
    pthread_mutex_lock(&m);
    printf("Waiter: calling cond_wait (will sleep forever)\n");
    pthread_cond_wait(&cv, &m);                /* BUG: no predicate checked */
    printf("Waiter: woken up\n");
    pthread_mutex_unlock(&m);
    return NULL;
}
void *signaller(void *a) {
    pthread_mutex_lock(&m);
    pthread_cond_signal(&cv);                  /* nobody is waiting yet: the signal is lost */
    printf("Signaller: signal sent (lost)\n");
    pthread_mutex_unlock(&m);
    return NULL;
}
int main(void) {
    pthread_t w, s;
    pthread_create(&w, NULL, waiter, NULL); pthread_create(&s, NULL, signaller, NULL);
    pthread_join(s, NULL); pthread_join(w, NULL);
    return 0;
}
