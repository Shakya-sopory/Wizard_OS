#include <stdio.h>
#include <stdlib.h>
static void sort(int *a, int n) { for (int i = 0; i < n - 1; i++) for (int j = 0; j < n - i - 1; j++) if (a[j] > a[j + 1]) { int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t; } }
int main(void) {
    int n, head, maxcyl;
    printf("Number of requests: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 100) return 1;
    int req[100];
    printf("Requests: "); for (int i = 0; i < n; i++) scanf("%d", &req[i]);
    printf("Head position and highest cylinder number (head moves towards max): ");
    scanf("%d %d", &head, &maxcyl);
    sort(req, n);
    int total = 0, cur = head;
    printf("Seek sequence: %d", cur);
    for (int i = 0; i < n; i++) if (req[i] >= head) { total += req[i] - cur; cur = req[i]; printf(" -> %d", cur); }
    total += maxcyl - cur; cur = maxcyl; printf(" -> %d", cur);                        /* reach the boundary */
    printf(" => 0 (jump, no service)"); cur = 0;
    for (int i = 0; i < n; i++) if (req[i] < head) { total += req[i] - cur; cur = req[i]; printf(" -> %d", cur); }
    int with_jump = total + maxcyl;               /* the return jump from maxcyl to 0 covers maxcyl cylinders, no service */
    printf("\nHead movement without the return jump = %d, including the jump of %d = %d cylinders\n", total, maxcyl, with_jump);
    return 0;
}
