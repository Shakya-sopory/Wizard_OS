#include <stdio.h>
#define MAXT 1000
int main(void) {
    int n;
    printf("Number of processes: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 20) return 1;
    int at[20], bt[20], rem[20], ct[20];
    for (int i = 0; i < n; i++) {
        printf("P%d arrival and burst time: ", i + 1);
        scanf("%d %d", &at[i], &bt[i]);
        rem[i] = bt[i];
    }
    int gantt[MAXT], len = 0, time = 0, done = 0;
    while (done < n && len < MAXT) {
        int pick = -1;
        for (int i = 0; i < n; i++)
            if (rem[i] > 0 && at[i] <= time && (pick == -1 || rem[i] < rem[pick])) pick = i;
        if (pick == -1) { gantt[len++] = -1; time++; continue; }   /* idle */
        gantt[len++] = pick;
        rem[pick]--; time++;
        if (rem[pick] == 0) { ct[pick] = time; done++; }
    }
    /* compress timeline into blocks */
    printf("\nGantt chart:\n|");
    for (int t = 0; t < len; t++)
        if (t == len - 1 || gantt[t] != gantt[t + 1]) {
            if (gantt[t] < 0) printf(" idle |"); else printf(" P%d |", gantt[t] + 1);
        }
    printf("\n0");
    for (int t = 0; t < len; t++)
        if (t == len - 1 || gantt[t] != gantt[t + 1]) { printf("%*d", (gantt[t] < 0 ? 8 : 5), t + 1); }
    printf("\n\nPID  AT  BT  CT  TAT  WT\n");
    double st = 0, sw = 0;
    for (int i = 0; i < n; i++) {
        int tat = ct[i] - at[i], wt = tat - bt[i];
        st += tat; sw += wt;
        printf("P%-3d %3d %3d %3d %4d %3d\n", i + 1, at[i], bt[i], ct[i], tat, wt);
    }
    printf("Average turnaround = %.2f, average waiting = %.2f\n", st / n, sw / n);
    return 0;
}
