#include <stdio.h>
static int fifo_lru_opt(int *ref, int n, int nf, int mode) {   /* mode 0 = LRU, 1 = Optimal */
    int frame[50], last[50], used = 0, faults = 0;
    for (int i = 0; i < n; i++) {
        int pos = -1;
        for (int j = 0; j < used; j++) if (frame[j] == ref[i]) { pos = j; break; }
        if (pos >= 0) { last[pos] = i; continue; }
        faults++;
        if (used < nf) { frame[used] = ref[i]; last[used] = i; used++; continue; }
        int victim = 0;
        if (mode == 0) {
            for (int j = 1; j < nf; j++) if (last[j] < last[victim]) victim = j;
        } else {
            int far = -1;
            for (int j = 0; j < nf; j++) {                  /* look ahead for next use */
                int k = i + 1;
                while (k < n && ref[k] != frame[j]) k++;
                if (k == n) { victim = j; break; }          /* never used again */
                if (k > far) { far = k; victim = j; }
            }
        }
        frame[victim] = ref[i]; last[victim] = i;
    }
    return faults;
}
int main(void) {
    int nf, n, ref[200];
    printf("Number of frames: ");
    if (scanf("%d", &nf) != 1 || nf <= 0 || nf > 50) return 1;
    printf("Length of reference string: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > 200) return 1;
    printf("Reference string: ");
    for (int i = 0; i < n; i++) scanf("%d", &ref[i]);
    int lru = fifo_lru_opt(ref, n, nf, 0), opt = fifo_lru_opt(ref, n, nf, 1);
    printf("LRU faults     = %d\nOptimal faults = %d\n", lru, opt);
    printf("Optimal is %d faults better than LRU (it is the lower bound; it cannot be implemented in a real OS).\n", lru - opt);
    return 0;
}
